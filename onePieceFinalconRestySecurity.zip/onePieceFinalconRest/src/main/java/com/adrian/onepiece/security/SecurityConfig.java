package com.adrian.onepiece.security;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.adrian.onepiece.jw.JwtAuthenticationFilter;
import com.adrian.onepiece.servicio.impl.DetallesUsuarioService;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

	@Autowired
	private DetallesUsuarioService userDetailsService;
	@Autowired
	private JwtAuthenticationFilter jwtAuthenticationFilter;

	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}

	@Bean
	public DaoAuthenticationProvider authenticationProvider() {
		DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider(userDetailsService);
		authProvider.setPasswordEncoder(passwordEncoder());
		return authProvider;
	}

	@Bean
	public AuthenticationManager authenticationManager(AuthenticationConfiguration authConfig) throws Exception {
		return authConfig.getAuthenticationManager();
	}

	@Bean
	public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
		http.csrf(csrf -> csrf.disable())
				.authorizeHttpRequests(
						auth -> auth.requestMatchers("/", "/login", "/accesoDenegado", "/css/**").permitAll()

								.requestMatchers("/home/**").authenticated().requestMatchers("/piratas/**")
								.hasAnyAuthority("almirante", "vicealmirante").requestMatchers("/tripulaciones/**")
								.hasAnyAuthority("almirante", "vicealmirante").requestMatchers("/recompensas/**")
								.hasAnyAuthority("almirante", "capitan").anyRequest().hasAuthority("almirante"))
				.formLogin(form -> form.loginPage("/login").defaultSuccessUrl("/home", true).permitAll())
				.logout(logout -> logout.logoutUrl("/logout").logoutSuccessUrl("/login?logout").permitAll())
				.exceptionHandling(exception -> exception.accessDeniedPage("/accesoDenegado"));
		return http.build();
	}
	
	@Bean
	@Order(1)
	public SecurityFilterChain securityFilterChain2(HttpSecurity http) throws Exception {
	    http
	        .securityMatcher(request -> {
	            String uri = request.getRequestURI();
	            return !uri.startsWith("/v1") && !uri.startsWith("/v2");
	        })
	        .csrf(csrf -> csrf.disable())
	        .authorizeHttpRequests(auth -> auth
	            .requestMatchers("/", "/login", "/accesoDenegado", "/css/**").permitAll()
	            .requestMatchers("/home/**").authenticated()
	            .requestMatchers("/piratas/**").hasAnyAuthority("almirante", "vicealmirante")
	            .requestMatchers("/tripulaciones/**").hasAnyAuthority("almirante", "vicealmirante")
	            .requestMatchers("/recompensas/**").hasAnyAuthority("almirante", "capitan")
	            .anyRequest().hasAuthority("almirante")
	        )
	        .formLogin(form -> form
	            .loginPage("/login")
	            .defaultSuccessUrl("/home", true)
	            .permitAll()
	        )
	        .logout(logout -> logout
	            .logoutUrl("/logout")
	            .logoutSuccessUrl("/login?logout")
	            .permitAll()
	        )
	        .exceptionHandling(exception -> exception
	            .accessDeniedPage("/accesoDenegado")
	        );

	    return http.build();
	}
	
	@Bean
	@Order(2)
	public SecurityFilterChain apiSecurityFilterChain(HttpSecurity http,JwtAuthenticationFilter jwtAuthenticationFilter) throws Exception {
	    http
	        .securityMatcher("/v1/**", "/v2/**")
	        .csrf(csrf -> csrf.disable())
	        .sessionManagement(session -> session
	            .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
	        )
	        .authorizeHttpRequests(auth -> auth
	            .requestMatchers("/v1/login/**", "/v2/login/**").permitAll()
	            .requestMatchers("/error").permitAll()
	            .requestMatchers("/v1/piratas/**", "/v2/piratas/**").hasAnyAuthority("almirante", "vicealmirante")
	            .requestMatchers("/v1/tripulaciones/**", "/v2/tripulaciones/**").hasAnyAuthority("almirante", "vicealmirante")
	            .requestMatchers("/v1/recompensas/**", "/v2/recompensas/**")
	                .hasAnyAuthority("almirante", "capitan")
	            .anyRequest().authenticated()
	        )
	        .exceptionHandling(exceptions -> exceptions
	            .authenticationEntryPoint((request, response, authException) -> {
	                response.setContentType("application/json;charset=UTF-8");
	                response.setStatus(HttpStatus.UNAUTHORIZED.value());
	                response.getWriter().write(
	                    "{\"timestamp\":\"" + LocalDateTime.now() + "\"," +
	                    "\"status\":401," +
	                    "\"error\":\"No autorizado\"," +
	                    "\"message\":\"Token no válido o no proporcionado\"}"
	                );
	            })
	            .accessDeniedHandler((request, response, accessDeniedException) -> {
	                response.setContentType("application/json;charset=UTF-8");
	                response.setStatus(HttpStatus.FORBIDDEN.value());
	                response.getWriter().write(
	                    "{\"timestamp\":\"" + LocalDateTime.now() + "\"," +
	                    "\"status\":403," +
	                    "\"error\":\"Acceso denegado\"," +
	                    "\"message\":\"No tienes permisos para acceder a este recurso\"}"
	                );
	            })
	        )
	        .addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class);

	    return http.build();
	}
}
