package com.adrian.onepiece.servicio.interfaces;

import java.util.ArrayList;

import com.adrian.onepiece.dtos.TesoreriaDTO;

public interface ITesoreriaService {

    ArrayList<TesoreriaDTO> listarTodasLasOperaciones();
}
