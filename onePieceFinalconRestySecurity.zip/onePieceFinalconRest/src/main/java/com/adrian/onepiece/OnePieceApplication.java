package com.adrian.onepiece;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnePieceApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnePieceApplication.class, args);
	}

}
