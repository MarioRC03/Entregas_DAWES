package com.adrian.onepiece.dao.interfaces;

import java.util.ArrayList;

import com.adrian.onepiece.dtos.TesoreriaDTO;

public interface ITesoreriaDAO {

    ArrayList<TesoreriaDTO> listarTodasLasOperaciones();
}
