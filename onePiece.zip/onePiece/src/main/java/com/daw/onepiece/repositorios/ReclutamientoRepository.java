package com.daw.onepiece.repositorios;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.daw.onepiece.entities.ReclutamientoEntity;

import jakarta.transaction.Transactional;

public interface ReclutamientoRepository extends JpaRepository<ReclutamientoEntity, Long> {
	@Query("SELECT r FROM ReclutamientoEntity r WHERE r.tripulacion.id = :idTripulacion AND r.esMiembroActual = 1")
	List<ReclutamientoEntity> findMiembrosActualesByTripulacionId(@Param("idTripulacion") Long idTripulacion);

	@Query("SELECT COUNT(r) FROM ReclutamientoEntity r WHERE r.tripulacion.id = :idTripulacion AND r.esMiembroActual = 1")
	Integer countMiembrosByTripulacionId(@Param("idTripulacion") Long idTripulacion);

	@Modifying
	@Transactional
	@Query("UPDATE ReclutamientoEntity r SET r.esMiembroActual = 0 WHERE r.pirata.id = :idPirata AND r.esMiembroActual = 1")
	void desactivarReclutamientosDelPirata(@Param("idPirata") Integer idPirata);

	@Modifying
	@Transactional
	@Query("UPDATE ReclutamientoEntity r SET r.esMiembroActual = 0 WHERE r.id = :idReclutamiento")
	void eliminarMiembro(@Param("idReclutamiento") Long idReclutamiento);
}
