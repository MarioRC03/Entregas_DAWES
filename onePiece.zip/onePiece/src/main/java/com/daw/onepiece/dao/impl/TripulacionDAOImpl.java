package com.daw.onepiece.dao.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.daw.onepiece.dao.interfaces.ITripulacionDAO;
import com.daw.onepiece.dtos.TripulacionDTO;
import com.daw.onepiece.entities.TripulacionEntity;
import com.daw.onepiece.repositorios.ReclutamientoRepository;
import com.daw.onepiece.repositorios.TripulacionRepository;

@Repository
public class TripulacionDAOImpl implements ITripulacionDAO {
	@Autowired
    private TripulacionRepository tripulacionRepository;

    @Autowired
    private ReclutamientoRepository reclutamientoRepository;

    @Override
    public List<TripulacionDTO> listarTodas() {
        return tripulacionRepository.findAll()
                .stream()
                .map(this::convertirADto)
                .collect(Collectors.toList());
    }

    @Override
    public List<TripulacionDTO> buscarPorFiltros(Long id, String nombre, String barco, boolean soloActivas) {
        Integer activo = soloActivas ? 1 : null;
        List<TripulacionDTO> dtos = tripulacionRepository.buscarPorFiltros(id, nombre, barco, activo);
        
        // Enriquecer cada DTO con el número de miembros activos
        for (TripulacionDTO dto : dtos) {
            int numMiembros = reclutamientoRepository.countMiembrosByTripulacionId(dto.getId());
            dto.setNumeroMiembros(numMiembros);
        }
        
        return dtos;
    }

    @Override
    public TripulacionDTO obtenerPorId(Long id) {
        return tripulacionRepository.findById(id)
                .map(this::convertirADto)
                .orElse(null);
    }

    @Override
    public Long insertar(String nombre, String barco) {
        TripulacionEntity entity = new TripulacionEntity();
        entity.setNombre(nombre);
        entity.setBarco(barco);
        entity.setEstaActiva(1); // Siempre activa al crear
        
        TripulacionEntity guardada = tripulacionRepository.save(entity);
        return guardada.getId();
    }

    @Override
    public Long actualizar(Long id, String nombre, String barco) {
        return tripulacionRepository.findById(id)
                .map(entity -> {
                    if (nombre != null && !nombre.trim().isEmpty()) {
                        entity.setNombre(nombre);
                    }
                    if (barco != null && !barco.trim().isEmpty()) {
                        entity.setBarco(barco);
                    }
                    tripulacionRepository.save(entity);
                    return entity.getId();
                })
                .orElse(null);
    }

    @Override
    public boolean borrar(Long id) {
        return tripulacionRepository.findById(id)
                .map(entity -> {
                    entity.setEstaActiva(0);
                    tripulacionRepository.save(entity);
                    return true;
                })
                .orElse(false);
    }

    // Método privado de conversión Entity → DTO (incluye conteo de miembros)
    private TripulacionDTO convertirADto(TripulacionEntity entity) {
        if (entity == null) {
            return null;
        }
        
        int numeroMiembros = reclutamientoRepository.countMiembrosByTripulacionId(entity.getId());
        
        return new TripulacionDTO(
                entity.getId(),
                entity.getNombre(),
                entity.getBarco(),
                entity.getEstaActiva(),
                numeroMiembros
        );
    }
}
