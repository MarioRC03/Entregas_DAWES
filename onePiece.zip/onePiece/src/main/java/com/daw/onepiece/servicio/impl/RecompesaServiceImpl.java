package com.daw.onepiece.servicio.impl;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.daw.onepiece.dao.interfaces.IRecompesaDAO;
import com.daw.onepiece.dtos.RecompensaDTO;
import com.daw.onepiece.repositorios.RecompensaRepository;
import com.daw.onepiece.servicio.interfaces.IRecompensaService;
import com.daw.onepiece.servicio.interfaces.ITesoreriaService;

import jakarta.transaction.Transactional;

@Service
public class RecompesaServiceImpl implements IRecompensaService{
	@Autowired
    private IRecompesaDAO recompensasDAO;

    @Autowired
    private RecompensaRepository recompensasRepository;

    @Autowired
    private ITesoreriaService tesoreriaService;

    @Override
    public ArrayList<RecompensaDTO> obtenerRecompensas() {
        return recompensasDAO.obtenerTodasRecompensas();
    }

    @Override
    public ArrayList<RecompensaDTO> obtenerRecompensasPorFiltros(
            Integer id,
            String nombrePirata,
            Long cantidadMin,
            Integer estaVigente) {
        return recompensasDAO.obtenerRecompensasPorFiltros(id, nombrePirata, cantidadMin, estaVigente);
    }

    @Override
    @Transactional
    public int emitirRecompensa(Integer pirataId, Long cantidad) {
        if (cantidad == null || cantidad <= 0) {
            throw new IllegalArgumentException("La cantidad de la recompensa debe ser mayor que 0");
        }

        
        recompensasRepository.findVigentesByPirataId(pirataId)
                .forEach(r -> {
                    r.setEstaVigente(0);
                    recompensasRepository.save(r);
                });

      
        int nuevoId = recompensasDAO.emitirRecompensa(pirataId, cantidad);

    
        tesoreriaService.registrarOperacion("EMISION RECOMPENSA", 10000L);

        return nuevoId;
    }

    @Override
    public int actualizarRecompensa(Integer id, Integer pirataId, Long cantidad, Integer estaVigente) {
        return recompensasDAO.actualizarRecompensa(id, pirataId, cantidad, estaVigente);
    }

    @Override
    public int borrarRecompensa(Integer id) {
        return recompensasDAO.borrarRecompensa(id);
    }
}

    
   

    