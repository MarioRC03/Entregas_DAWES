package com.daw.onepiece.dao.impl;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.daw.onepiece.dao.interfaces.IPiratasDAO;
import com.daw.onepiece.dtos.PiratasDTO;
import com.daw.onepiece.entities.PiratasEntity;
import com.daw.onepiece.repositorios.PiratasRepository;

@Repository
public class PiratasDAOImpl implements IPiratasDAO {
	@Autowired
    private PiratasRepository piratasRepository;

    @Override
    public ArrayList<PiratasDTO> obtenerTodasPiratas() {
        // Puedes implementar con findAll() + conversión si lo necesitas
        return new ArrayList<>();
    }

    @Override
    public ArrayList<PiratasDTO> obtenerPiratasPorFiltros(Integer id, String nombre,
            String frutaDiablo, Integer activo) {
        if (activo == null) activo = 1; // valor por defecto si no filtras
        return piratasRepository.buscarPiratasPorFiltros(id, nombre, frutaDiablo, activo);
    }

    @Override
    public int insertarPirata(Integer id, String nombre, String frutaDiablo,
            String fechaNacimiento, Integer idIsla, Integer activo) {

        PiratasEntity entity = new PiratasEntity(id, nombre, frutaDiablo,
                fechaNacimiento, idIsla, activo != null ? activo : 1);
        piratasRepository.save(entity);
        return entity.getId();
    }

    @Override
    public int actualizarPirata(Integer id, String nombre, String frutaDiablo,
            String fechaNacimiento, Integer idIsla, Integer activo) {

        return piratasRepository.findById(id)
                .map(entity -> {
                    if (nombre != null) entity.setNombre(nombre);
                    if (frutaDiablo != null) entity.setFrutaDiablo(frutaDiablo);
                    if (fechaNacimiento != null) entity.setFechaNacimiento(fechaNacimiento);
                    if (idIsla != null) entity.setIdIsla(idIsla);
                    if (activo != null) entity.setActivo(activo);
                    piratasRepository.save(entity);
                    return entity.getId();
                })
                .orElse(0);
    }

    @Override
    public int borrarPirata(Integer id) {
        return piratasRepository.findById(id)
                .map(entity -> {
                    entity.setActivo(0);
                    piratasRepository.save(entity);
                    return entity.getId();
                })
                .orElse(0);
    }
}
