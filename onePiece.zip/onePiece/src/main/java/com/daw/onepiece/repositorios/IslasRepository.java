package com.daw.onepiece.repositorios;

import org.springframework.data.repository.CrudRepository;

import com.daw.onepiece.entities.IslaEntity;

public interface IslasRepository extends CrudRepository<IslaEntity, Integer> {

}
