package com.daw.onepiece.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "pirata")
public class PiratasEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;

	@Column(name = "nombre")
	private String nombre;

	@Column(name = "frutadeldiablo")
	private String frutaDiablo;

	@Column(name = "fechanacimiento")
	private String fechaNacimiento; // ← string tal como en tus formularios

	@Column(name = "isla_id")
	private Integer idIsla;

	@Column(name = "estaactivo")
	private Integer activo;

	public PiratasEntity() {
		super();
	}

	public PiratasEntity(Integer id, String nombre, String frutaDiablo, String fechaNacimiento, Integer idIsla,
			Integer activo) {
		super();
		this.id = id;
		this.nombre = nombre;
		this.frutaDiablo = frutaDiablo;
		this.fechaNacimiento = fechaNacimiento;
		this.idIsla = idIsla;
		this.activo = activo;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getFrutaDiablo() {
		return frutaDiablo;
	}

	public void setFrutaDiablo(String frutaDiablo) {
		this.frutaDiablo = frutaDiablo;
	}

	public String getFechaNacimiento() {
		return fechaNacimiento;
	}

	public void setFechaNacimiento(String fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}

	public Integer getIdIsla() {
		return idIsla;
	}

	public void setIdIsla(Integer idIsla) {
		this.idIsla = idIsla;
	}

	public Integer getActivo() {
		return activo;
	}

	public void setActivo(Integer activo) {
		this.activo = activo;
	}
}
