package com.daw.onepiece.dtos;

public class RecompensaDTO {
	private Integer id;
	private Integer pirataId;
	private Long cantidad;
	private Integer estaVigente;

	
	private String nombrePirata;
	private String tripulacion; 

	public RecompensaDTO() {
		super();
	}

	public RecompensaDTO(Integer id, Integer pirataId, Long cantidad, Integer estaVigente, String nombrePirata,
			String tripulacion) {
		this.id = id;
		this.pirataId = pirataId;
		this.cantidad = cantidad;
		this.estaVigente = estaVigente;
		this.nombrePirata = nombrePirata;
		this.tripulacion = tripulacion;
	}



	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getPirataId() {
		return pirataId;
	}

	public void setPirataId(Integer pirataId) {
		this.pirataId = pirataId;
	}

	public Long getCantidad() {
		return cantidad;
	}

	public void setCantidad(Long cantidad) {
		this.cantidad = cantidad;
	}

	public Integer getEstaVigente() {
		return estaVigente;
	}

	public void setEstaVigente(Integer estaVigente) {
		this.estaVigente = estaVigente;
	}

	public String getNombrePirata() {
		return nombrePirata;
	}

	public void setNombrePirata(String nombrePirata) {
		this.nombrePirata = nombrePirata;
	}

	public String getTripulacion() {
		return tripulacion;
	}

	public void setTripulacion(String tripulacion) {
		this.tripulacion = tripulacion;
	}
}
