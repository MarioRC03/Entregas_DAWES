package com.daw.onepiece.dao.interfaces;

import java.util.ArrayList;

import com.daw.onepiece.dtos.PiratasDTO;

public interface IPiratasDAO {
	ArrayList<PiratasDTO> obtenerTodasPiratas();

	ArrayList<PiratasDTO> obtenerPiratasPorFiltros(Integer id, String nombre, String frutaDiablo, Integer activo);

	int insertarPirata(Integer id, String nombre, String frutaDiablo, String fechaNacimiento, Integer idIsla,
			Integer activo);

	int actualizarPirata(Integer id, String nombre, String frutaDiablo, String fechaNacimiento, Integer idIsla,
			Integer activo);

	int borrarPirata(Integer id);
}
