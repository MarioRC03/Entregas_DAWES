package com.daw.onepiece.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "recompensa")
public class RecompensaEntity {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @Column(name = "pirata_id")
    private Integer pirataId;

    @Column(name = "cantidad")
    private Long cantidad;          

    @Column(name = "estavigente")
    private Integer estaVigente;

    public RecompensaEntity() {
        super();
    }

    public RecompensaEntity(Integer id, Integer pirataId, Long cantidad, Integer estaVigente) {
        super();
        this.id = id;
        this.pirataId = pirataId;
        this.cantidad = cantidad;
        this.estaVigente = estaVigente;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getPirataId() {
        return pirataId;
    }

    public void setPirataId(Integer pirataId) {
        this.pirataId = pirataId;
    }

    public Long getCantidad() {
        return cantidad;
    }

    public void setCantidad(Long cantidad) {
        this.cantidad = cantidad;
    }

    public Integer getEstaVigente() {
        return estaVigente;
    }

    public void setEstaVigente(Integer estaVigente) {
        this.estaVigente = estaVigente;
    }
}
