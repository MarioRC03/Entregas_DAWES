package com.daw.onepiece.servicio.interfaces;

import java.util.ArrayList;

import com.daw.onepiece.dtos.RecompensaDTO;

public interface IRecompensaService {
	ArrayList<RecompensaDTO> obtenerRecompensas();

	ArrayList<RecompensaDTO> obtenerRecompensasPorFiltros(Integer id, String nombrePirata, Long cantidadMin,
			Integer estaVigente);

	int emitirRecompensa(Integer pirataId, Long cantidad);

	int actualizarRecompensa(Integer id, Integer pirataId, Long cantidad, Integer estaVigente);

	int borrarRecompensa(Integer id);
}
