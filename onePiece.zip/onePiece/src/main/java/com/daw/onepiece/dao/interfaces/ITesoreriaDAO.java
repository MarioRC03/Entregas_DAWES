package com.daw.onepiece.dao.interfaces;

import java.util.ArrayList;

import com.daw.onepiece.dtos.TesoreriaDTO;



public interface ITesoreriaDAO {

    ArrayList<TesoreriaDTO> listarTodasLasOperaciones();
}
