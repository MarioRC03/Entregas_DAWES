package com.daw.onepiece.dao.impl;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.daw.onepiece.dao.interfaces.IRecompesaDAO;
import com.daw.onepiece.dtos.RecompensaDTO;
import com.daw.onepiece.entities.RecompensaEntity;
import com.daw.onepiece.repositorios.RecompensaRepository;

@Repository
public class RecompensaDAOImpl implements IRecompesaDAO{
	@Autowired
    private RecompensaRepository recompensasRepository;

    @Override
    public ArrayList<RecompensaDTO> obtenerTodasRecompensas() {
        return new ArrayList<>();
     
    }

    @Override
    public ArrayList<RecompensaDTO> obtenerRecompensasPorFiltros(Integer id, String nombrePirata,
                                                                   Long cantidadMin, Integer estaVigente
                                                                   ) {
        if (estaVigente == null) estaVigente = 1;
        return recompensasRepository.buscarRecompensasPorFiltros(id, nombrePirata, cantidadMin, estaVigente);
    }
    

    @Override
    public int emitirRecompensa(Integer pirataId, Long cantidad) {
    
        recompensasRepository.findVigentesByPirataId(pirataId)
                .forEach(r -> {
                    r.setEstaVigente(0);
                    recompensasRepository.save(r);
                });

        RecompensaEntity entity = new RecompensaEntity();
        entity.setPirataId(pirataId);
        entity.setCantidad(cantidad);
        entity.setEstaVigente(1);

        recompensasRepository.save(entity);
        return entity.getId();
    }

    @Override
    public int actualizarRecompensa(Integer id, Integer pirataId, Long cantidad, Integer estaVigente) {
        return recompensasRepository.findById(id)
                .map(entity -> {
                    if (pirataId != null) entity.setPirataId(pirataId);
                    if (cantidad != null) entity.setCantidad(cantidad);
                    if (estaVigente != null) entity.setEstaVigente(estaVigente);
                    recompensasRepository.save(entity);
                    return entity.getId();
                })
                .orElse(0);
    }

    @Override
    public int borrarRecompensa(Integer id) {
        return recompensasRepository.findById(id)
                .map(entity -> {
                    entity.setEstaVigente(0);
                    recompensasRepository.save(entity);
                    return entity.getId();
                })
                .orElse(0);
    }
}
