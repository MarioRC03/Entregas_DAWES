package com.daw.onepiece.entities;



import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "isla")  // ← cambia si tu tabla se llama de otra forma
public class IslaEntity {

    @Id                     // ← ¡ESTO ES OBLIGATORIO!
    @Column(name = "id")
    private Integer id;

    @Column(name = "nombre")
    private String nombre;

    // Constructor vacío (obligatorio para JPA)
    public IslaEntity() {
    }

    // Constructor útil (opcional)
    public IslaEntity(Integer id, String nombre) {
        this.id = id;
        this.nombre = nombre;
    }

    // Getters y setters
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}
