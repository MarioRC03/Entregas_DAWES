package com.daw.onepiece.dtos;

public class MiembroTripulacionDTO {
	private Integer idPirata;
    private Long idReclutamiento;
    private String nombre;
    private String rol;
    private String frutaDiablo;

    public MiembroTripulacionDTO(Integer idPirata, Long idReclutamiento, String nombre, String rol, String frutaDiablo) {
        this.idPirata = idPirata;
        this.idReclutamiento = idReclutamiento;
        this.nombre = nombre;
        this.rol = rol;
        this.frutaDiablo = frutaDiablo;
    }

    // Getters y Setters
    public Integer getIdPirata() {
        return idPirata;
    }

    public void setIdPirata(Integer idPirata) {
        this.idPirata = idPirata;
    }

    public Long getIdReclutamiento() {
        return idReclutamiento;
    }

    public void setIdReclutamiento(Long idReclutamiento) {
        this.idReclutamiento = idReclutamiento;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }

    public String getFrutaDiablo() {
        return frutaDiablo;
    }

    public void setFrutaDiablo(String frutaDiablo) {
        this.frutaDiablo = frutaDiablo;
    }
}
