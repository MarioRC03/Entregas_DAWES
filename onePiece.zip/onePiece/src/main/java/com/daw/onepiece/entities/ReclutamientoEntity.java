package com.daw.onepiece.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "reclutamiento")
public class ReclutamientoEntity {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @ManyToOne
    @JoinColumn(name = "pirata_id")
    private PiratasEntity pirata;

    @ManyToOne
    @JoinColumn(name = "tripulacion_id")
    private TripulacionEntity tripulacion;

    @Column(name = "rol")
    private String rol;

    @Column(name = "esmiembroactual")
    private Integer esMiembroActual;

    public ReclutamientoEntity() {
    }

    public ReclutamientoEntity(PiratasEntity pirata, TripulacionEntity tripulacion, String rol, Integer esMiembroActual) {
        this.pirata = pirata;
        this.tripulacion = tripulacion;
        this.rol = rol;
        this.esMiembroActual = esMiembroActual;
    }

    // Getters y Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public PiratasEntity getPirata() {
        return pirata;
    }

    public void setPirata(PiratasEntity pirata) {
        this.pirata = pirata;
    }

    public TripulacionEntity getTripulacion() {
        return tripulacion;
    }

    public void setTripulacion(TripulacionEntity tripulacion) {
        this.tripulacion = tripulacion;
    }

    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }

    public Integer getEsMiembroActual() {
        return esMiembroActual;
    }

    public void setEsMiembroActual(Integer esMiembroActual) {
        this.esMiembroActual = esMiembroActual;
    }
}
