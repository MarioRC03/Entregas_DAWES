package com.daw.onepiece.dao.interfaces;

import java.util.List;

import com.daw.onepiece.dtos.TripulacionDTO;

public interface ITripulacionDAO {
	
    List<TripulacionDTO> listarTodas();

    
    List<TripulacionDTO> buscarPorFiltros(Long id, String nombre, String barco, boolean soloActivas);

   
    TripulacionDTO obtenerPorId(Long id);

   
    Long insertar(String nombre, String barco);

    
    Long actualizar(Long id, String nombre, String barco);

   
    boolean borrar(Long id);
}
