package com.daw.onepiece.controladores;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.daw.onepiece.dao.interfaces.IDesplegableDAO;
import com.daw.onepiece.dtos.PiratasDTO;
import com.daw.onepiece.servicio.interfaces.IPiratasService;

@Controller
@RequestMapping("/piratas")
public class PiratasController {
	@Autowired
    private IPiratasService piratasService;

    @Autowired
    private IDesplegableDAO desplegableDAO;  // para cargar islas


    @GetMapping("/listadoPiratas")
    public String mostrarFormularioListado(ModelMap model) {
        return "piratas/listadoPiratas";
    }

    @PostMapping("/listadoPiratas")
    public String procesarListadoPiratas(
            @RequestParam(value = "id", required = false) Integer id,
            @RequestParam(value = "nombre", required = false) String nombre,
            @RequestParam(value = "frutaDiablo", required = false) String frutaDiablo,
            @RequestParam(value = "activo", required = false) String activoStr,
            ModelMap model) {

        Integer activo = (activoStr != null && activoStr.equals("1")) ? 1 : null;

        ArrayList<PiratasDTO> lista = piratasService.obtenerPiratasPorFiltros(
                id, nombre, frutaDiablo, activo);

        model.addAttribute("lista", lista);
        return "piratas/listadoPiratas";
    }


    @GetMapping("/insertarPirata")
    public String mostrarFormularioInsertar(ModelMap model) {
        model.addAttribute("desplegableIslas", desplegableDAO.obtenerIslas());
        return "piratas/insertarPirata";   // ← con "s" al final
    }

    @PostMapping("/insertarPirata")
    public String procesarInsertarPirata(
            @RequestParam(value = "id", required = false) Integer id,
            @RequestParam("nombre") String nombre,
            @RequestParam(value = "frutaDiablo", required = false) String frutaDiablo,
            @RequestParam("fechaNacimiento") String fechaNacimiento,
            @RequestParam("islas") Integer idIsla,           // ← coincide con name="islas"
            @RequestParam(value = "activo", required = false) String activoStr,
            ModelMap model) {

        Integer activo = (activoStr != null && activoStr.equals("1")) ? 1 : 0;

        int resultado = piratasService.insertarPirata(
                id, nombre, frutaDiablo, fechaNacimiento, idIsla, activo);

        model.addAttribute("resultado", resultado);
        model.addAttribute("desplegableIslas", desplegableDAO.obtenerIslas()); // por si recarga
        return "piratas/insertarPirata";
    }


    @GetMapping("/formularioActualizarPiratas")
    public String mostrarFormularioActualizar(ModelMap model) {
        model.addAttribute("desplegableIslas", desplegableDAO.obtenerIslas());
        return "piratas/actualizarPiratas";
    }

    @PostMapping("/formularioActualizarPiratas")
    public String buscarParaActualizar(
            @RequestParam(value = "id", required = false) Integer id,
            @RequestParam(value = "nombre", required = false) String nombre,
            @RequestParam(value = "frutaDiablo", required = false) String frutaDiablo,
            @RequestParam(value = "activo", required = false) String activoStr,
            ModelMap model) {

        Integer activo = (activoStr != null && activoStr.equals("1")) ? 1 : null;

        ArrayList<PiratasDTO> lista = piratasService.obtenerPiratasPorFiltros(
                id, nombre, frutaDiablo, activo);

        model.addAttribute("lista", lista);
        model.addAttribute("desplegableIslas", desplegableDAO.obtenerIslas());
        return "piratas/actualizarPiratas";
    }

    @PostMapping("/actualizarPirata")
    public String procesarActualizarPirata(
            @RequestParam("id") Integer id,
            @RequestParam(value = "nombre", required = false) String nombre,
            @RequestParam(value = "frutaDiablo", required = false) String frutaDiablo,
            @RequestParam(value = "fechaNacimiento", required = false) String fechaNacimiento,
            @RequestParam("isla") Integer idIsla,           // ← name="isla" en el HTML
            @RequestParam(value = "activo", required = false) String activoStr,
            ModelMap model) {

        Integer activo = null;
        if (activoStr != null && !activoStr.isEmpty()) {
            activo = activoStr.equals("1") ? 1 : 0;
        }

        int resultado = piratasService.actualizarPirata(
                id, nombre, frutaDiablo, fechaNacimiento, idIsla, activo);

        model.addAttribute("resultado", resultado);
        model.addAttribute("desplegableIslas", desplegableDAO.obtenerIslas());
        return "piratas/actualizarPiratas";
    }


    @GetMapping("/formularioBorrarPiratas")
    public String mostrarFormularioBorrar(ModelMap model) {
        return "piratas/borrarPiratas";
    }

    @PostMapping("/formularioBorrarPiratas")
    public String buscarParaBorrar(
            @RequestParam(value = "id", required = false) Integer id,
            @RequestParam(value = "nombre", required = false) String nombre,
            ModelMap model) {

        ArrayList<PiratasDTO> lista = piratasService.obtenerPiratasPorFiltros(
                id, nombre, null, 1);

        model.addAttribute("lista", lista);
        return "piratas/borrarPiratas";
    }

    @PostMapping("/borrarPirata")
    public String procesarBorrarPirata(
            @RequestParam("id") Integer id,
            ModelMap model) {

        int resultado = piratasService.borrarPirata(id);
        model.addAttribute("resultado", resultado);
        return "piratas/borrarPiratas";
    }
}
