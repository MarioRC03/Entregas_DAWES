package com.daw.onepiece.servicio.impl;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.daw.onepiece.dao.interfaces.IPiratasDAO;
import com.daw.onepiece.dtos.PiratasDTO;
import com.daw.onepiece.servicio.interfaces.IPiratasService;

@Service
public class PiratasServiceImp implements IPiratasService{
	@Autowired
    private IPiratasDAO piratasDAO;

    @Override
    public ArrayList<PiratasDTO> obtenerPiratas() {
        return piratasDAO.obtenerTodasPiratas();
    }

    @Override
    public ArrayList<PiratasDTO> obtenerPiratasPorFiltros(Integer id, String nombre,
            String frutaDiablo, Integer activo) {
        return piratasDAO.obtenerPiratasPorFiltros(id, nombre, frutaDiablo, activo);
    }

    @Override
    public int insertarPirata(Integer id, String nombre, String frutaDiablo,
            String fechaNacimiento, Integer idIsla, Integer activo) {
        return piratasDAO.insertarPirata(id, nombre, frutaDiablo, fechaNacimiento, idIsla, activo);
    }

    @Override
    public int actualizarPirata(Integer id, String nombre, String frutaDiablo,
            String fechaNacimiento, Integer idIsla, Integer activo) {
        return piratasDAO.actualizarPirata(id, nombre, frutaDiablo, fechaNacimiento, idIsla, activo);
    }

    @Override
    public int borrarPirata(Integer id) {
        return piratasDAO.borrarPirata(id);
    }
}
