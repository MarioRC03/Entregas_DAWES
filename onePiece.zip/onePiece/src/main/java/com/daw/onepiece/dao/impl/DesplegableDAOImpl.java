package com.daw.onepiece.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.daw.onepiece.dao.interfaces.IDesplegableDAO;
import com.daw.onepiece.dtos.DesplegableDTO;
import com.daw.onepiece.entities.IslaEntity;
import com.daw.onepiece.entities.PiratasEntity;
import com.daw.onepiece.entities.TripulacionEntity;
import com.daw.onepiece.repositorios.IslasRepository;
import com.daw.onepiece.repositorios.PiratasRepository;
import com.daw.onepiece.repositorios.TripulacionRepository;


@Repository
public class DesplegableDAOImpl implements IDesplegableDAO{
	@Autowired
    private IslasRepository islasRepository;
	
	@Autowired
    private PiratasRepository piratasRepository;

    @Autowired
    private TripulacionRepository tripulacionRepository;

    @Override
    public ArrayList<DesplegableDTO> obtenerIslas() {
        Iterable<IslaEntity> listaEntidades = islasRepository.findAll();
        ArrayList<DesplegableDTO> listaIslas = new ArrayList<>();

        for (IslaEntity isla : listaEntidades) {
            listaIslas.add(new DesplegableDTO(isla.getId(), isla.getNombre()));
        }

        return listaIslas;
    }
    
    @Override
    public ArrayList<DesplegableDTO> obtenerPiratasActivos() {
        Iterable<PiratasEntity> listaEntidades = piratasRepository.findAllActivos(); // usa tu método de activos
        // Si no tienes findAllActivos(), puedes usar: piratasRepository.findByActivo(1)
        ArrayList<DesplegableDTO> lista = new ArrayList<>();
        for (PiratasEntity p : listaEntidades) {
            lista.add(new DesplegableDTO(p.getId(), p.getNombre()));
        }
        return lista;
    }

    @Override
    public ArrayList<DesplegableDTO> obtenerTripulacionesActivas() {
        List<TripulacionEntity> listaEntidades = tripulacionRepository.findTripulacionesActivas();
        ArrayList<DesplegableDTO> lista = new ArrayList<>();
        for (TripulacionEntity t : listaEntidades) {
            lista.add(new DesplegableDTO(t.getId().intValue(), t.getNombre()));
        }
        return lista;
    }
}
