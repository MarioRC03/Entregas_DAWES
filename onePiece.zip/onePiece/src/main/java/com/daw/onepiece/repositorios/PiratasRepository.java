package com.daw.onepiece.repositorios;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.daw.onepiece.dtos.PiratasDTO;
import com.daw.onepiece.entities.PiratasEntity;

public interface PiratasRepository extends CrudRepository<PiratasEntity, Integer> {

	@Query("""
			SELECT new com.daw.onepiece.dtos.PiratasDTO(
			    p.id,
			    p.nombre,
			    p.frutaDiablo,
			    p.fechaNacimiento,
			    p.idIsla,
			    null,
			    p.activo,
			    null
			)
			FROM PiratasEntity p
			WHERE (:id IS NULL OR CAST(p.id AS string) LIKE CONCAT('%', :id, '%'))
			  AND (:nombre IS NULL OR p.nombre LIKE CONCAT('%', :nombre, '%'))
			  AND (:frutaDiablo IS NULL OR p.frutaDiablo LIKE CONCAT('%', :frutaDiablo, '%'))
			  AND p.activo = :activo
			""")
	ArrayList<PiratasDTO> buscarPiratasPorFiltros(@Param("id") Integer id, @Param("nombre") String nombre,
			@Param("frutaDiablo") String frutaDiablo, @Param("activo") Integer activo);
	
	@Query("SELECT p FROM PiratasEntity p WHERE p.activo = 1")
    List<PiratasEntity> findAllActivos();
}