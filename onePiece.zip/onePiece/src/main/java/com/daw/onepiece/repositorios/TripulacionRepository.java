package com.daw.onepiece.repositorios;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.daw.onepiece.dtos.TripulacionDTO;
import com.daw.onepiece.entities.TripulacionEntity;

public interface TripulacionRepository extends JpaRepository<TripulacionEntity, Long>{
	@Query("SELECT new com.daw.onepiece.dtos.TripulacionDTO(" +
		       "t.id, t.nombre, t.barco, t.estaActiva, 0) " +  
		       "FROM TripulacionEntity t " +
		       "WHERE (:id IS NULL OR CAST(t.id AS string) LIKE CONCAT('%', :id, '%')) " +
		       "AND (:nombre IS NULL OR t.nombre LIKE CONCAT('%', :nombre, '%')) " +
		       "AND (:barco IS NULL OR t.barco LIKE CONCAT('%', :barco, '%')) " +
		       "AND t.estaActiva = :activa")
		List<TripulacionDTO> buscarPorFiltros(
		        @Param("id") Long id,
		        @Param("nombre") String nombre,
		        @Param("barco") String barco,
		        @Param("activa") Integer activa);
	
	@Query("SELECT t FROM TripulacionEntity t WHERE t.estaActiva = 1")
    List<TripulacionEntity> findTripulacionesActivas();
}
