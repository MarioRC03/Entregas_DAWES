package com.daw.onepiece.dao.interfaces;

import java.util.ArrayList;

import com.daw.onepiece.dtos.DesplegableDTO;


public interface IDesplegableDAO {
	ArrayList<DesplegableDTO> obtenerIslas();
	ArrayList<DesplegableDTO> obtenerPiratasActivos();

    ArrayList<DesplegableDTO> obtenerTripulacionesActivas();
}
