package com.daw.onepiece.dtos;

import java.time.LocalDate;

public class PiratasDTO {

	private Integer id;
	private String nombre;
	private String frutaDiablo;
	private String fechaNacimiento;
	private Integer idIsla;
	private String isla; // nombre para mostrar (se rellena en el DAO si hace falta)
	private Integer activo;
	private String tripulacion; // nombre para mostrar (opcional)

	public PiratasDTO() {
		super();
	}

	public PiratasDTO(Integer id, String nombre, String frutaDiablo, String fechaNacimiento, Integer idIsla,
			String isla, Integer activo, String tripulacion) {
		this.id = id;
		this.nombre = nombre;
		this.frutaDiablo = frutaDiablo;
		this.fechaNacimiento = fechaNacimiento;
		this.idIsla = idIsla;
		this.isla = isla;
		this.activo = activo;
		this.tripulacion = tripulacion;
	}

	// Getters y setters (todos)
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getFrutaDiablo() {
		return frutaDiablo;
	}

	public void setFrutaDiablo(String frutaDiablo) {
		this.frutaDiablo = frutaDiablo;
	}

	public String getFechaNacimiento() {
		return fechaNacimiento;
	}

	public void setFechaNacimiento(String fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}

	public Integer getIdIsla() {
		return idIsla;
	}

	public void setIdIsla(Integer idIsla) {
		this.idIsla = idIsla;
	}

	public String getIsla() {
		return isla;
	}

	public void setIsla(String isla) {
		this.isla = isla;
	}

	public Integer getActivo() {
		return activo;
	}

	public void setActivo(Integer activo) {
		this.activo = activo;
	}

	public String getTripulacion() {
		return tripulacion;
	}

	public void setTripulacion(String tripulacion) {
		this.tripulacion = tripulacion;
	}
}
