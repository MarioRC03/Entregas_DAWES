package com.daw.onepiece.controladores;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.daw.onepiece.dao.interfaces.IDesplegableDAO;
import com.daw.onepiece.dtos.RecompensaDTO;
import com.daw.onepiece.repositorios.RecompensaRepository;
import com.daw.onepiece.servicio.interfaces.IRecompensaService;

@Controller
@RequestMapping("/recompensas")
public class RecompensaController {
	@Autowired
    private IRecompensaService recompensasService;

    @Autowired
    private IDesplegableDAO desplegableDAO;

    // ==================== LISTADO ====================
    @GetMapping("/listadoRecompensas")
    public String mostrarFormularioListado(ModelMap model) {
        model.addAttribute("tripulacionesActivas", desplegableDAO.obtenerTripulacionesActivas());
        return "recompensas/listadoRecompensas";
    }

    @PostMapping("/listadoRecompensas")
    public String procesarListado(
            @RequestParam(value = "nombrePirata", required = false) String nombrePirata,
            @RequestParam(value = "idTripulacion", required = false) Integer idTripulacion,
            @RequestParam(value = "cantidad", required = false) Long cantidadMin,
            @RequestParam(value = "estaVigente", required = false) String vigenteStr,
            ModelMap model) {

        Integer vigente = (vigenteStr != null && vigenteStr.equals("1")) ? 1 : null;

        ArrayList<RecompensaDTO> lista = recompensasService.obtenerRecompensasPorFiltros(
                null, nombrePirata, cantidadMin, vigente);

        model.addAttribute("lista", lista);
        model.addAttribute("tripulacionesActivas", desplegableDAO.obtenerTripulacionesActivas());
        return "recompensas/listadoRecompensas";
    }

    // ==================== EMITIR ====================
    @GetMapping("/emitirRecompensa")
    public String mostrarEmitir(ModelMap model) {
        model.addAttribute("piratasActivos", desplegableDAO.obtenerPiratasActivos());
        return "recompensas/emitirRecompensa";
    }

    @PostMapping("/emitirRecompensa")
    public String procesarEmitir(
            @RequestParam("idPirata") Integer pirataId,
            @RequestParam("cantidad") Long cantidad,
            ModelMap model) {

        try {
            int resultado = recompensasService.emitirRecompensa(pirataId, cantidad);
            model.addAttribute("resultado", resultado);
        } catch (Exception e) {
            model.addAttribute("error", e.getMessage());
        }

        model.addAttribute("piratasActivos", desplegableDAO.obtenerPiratasActivos());
        return "recompensas/emitirRecompensa";
    }

    // ==================== ACTUALIZAR ====================
    @GetMapping("/formularioActualizarRecompensas")
    public String mostrarFormularioActualizar(ModelMap model) {
        model.addAttribute("piratasActivos", desplegableDAO.obtenerPiratasActivos());
        return "recompensas/actualizarRecompensas";
    }

    @PostMapping("/formularioActualizarRecompensas")
    public String buscarParaActualizar(
            @RequestParam(value = "id", required = false) Integer id,
            @RequestParam(value = "nombrePirata", required = false) String nombrePirata,
            @RequestParam(value = "estaVigente", required = false) String vigenteStr,
            ModelMap model) {

        Integer vigente = (vigenteStr != null && vigenteStr.equals("1")) ? 1 : null;

    
        ArrayList<RecompensaDTO> lista = recompensasService.obtenerRecompensasPorFiltros(
                id, nombrePirata, null, vigente);

        model.addAttribute("lista", lista);
        model.addAttribute("piratasActivos", desplegableDAO.obtenerPiratasActivos());
        return "recompensas/actualizarRecompensas";
    }

    @PostMapping("/actualizarRecompensa")
    public String procesarActualizarRecompensa(
            @RequestParam("id") Integer id,
            @RequestParam("idPirata") Integer pirataId,
            @RequestParam("cantidad") Long cantidad,
            @RequestParam(value = "estaVigente", required = false) String vigenteStr,
            ModelMap model) {

        Integer vigente = null;
        if (vigenteStr != null && !vigenteStr.isEmpty()) {
            vigente = vigenteStr.equals("1") ? 1 : 0;
        }

        int resultado = recompensasService.actualizarRecompensa(id, pirataId, cantidad, vigente);
        model.addAttribute("resultado", resultado);
        model.addAttribute("piratasActivos", desplegableDAO.obtenerPiratasActivos());
        return "recompensas/actualizarRecompensas";
    }

    // ==================== BORRAR ====================
    @GetMapping("/formularioBorrarRecompensas")
    public String mostrarFormularioBorrar(ModelMap model) {
        return "recompensas/borrarRecompensas";
    }

    @PostMapping("/formularioBorrarRecompensas")
    public String buscarParaBorrar(
            @RequestParam(value = "id", required = false) Integer id,
            @RequestParam(value = "nombrePirata", required = false) String nombrePirata,
            ModelMap model) {

        // CORREGIDO: solo 4 parámetros
        ArrayList<RecompensaDTO> lista = recompensasService.obtenerRecompensasPorFiltros(
                id, nombrePirata, null, 1);

        model.addAttribute("lista", lista);
        return "recompensas/borrarRecompensas";
    }

    @PostMapping("/borrarRecompensa")
    public String procesarBorrarRecompensa(
            @RequestParam("id") Integer id,
            ModelMap model) {

        int resultado = recompensasService.borrarRecompensa(id);
        model.addAttribute("resultado", resultado);
        return "recompensas/borrarRecompensas";
    }
}
