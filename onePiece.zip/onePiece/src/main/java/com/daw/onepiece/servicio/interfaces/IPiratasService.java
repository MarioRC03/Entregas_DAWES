package com.daw.onepiece.servicio.interfaces;

import java.util.ArrayList;

import com.daw.onepiece.dtos.PiratasDTO;

public interface IPiratasService {
	ArrayList<PiratasDTO> obtenerPiratas();

    ArrayList<PiratasDTO> obtenerPiratasPorFiltros(Integer id, String nombre,
            String frutaDiablo, Integer activo);

    int insertarPirata(Integer id, String nombre, String frutaDiablo,
            String fechaNacimiento, Integer idIsla, Integer activo);

    int actualizarPirata(Integer id, String nombre, String frutaDiablo,
            String fechaNacimiento, Integer idIsla, Integer activo);

    int borrarPirata(Integer id);
}
