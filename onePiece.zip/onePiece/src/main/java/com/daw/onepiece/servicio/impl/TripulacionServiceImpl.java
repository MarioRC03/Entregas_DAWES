package com.daw.onepiece.servicio.impl;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.daw.onepiece.dtos.TripulacionDTO;
import com.daw.onepiece.entities.TripulacionEntity;
import com.daw.onepiece.repositorios.ReclutamientoRepository;
import com.daw.onepiece.repositorios.TripulacionRepository;
import com.daw.onepiece.servicio.interfaces.ITripulacionService;

@Service
public class TripulacionServiceImpl implements ITripulacionService{
	@Autowired
    private TripulacionRepository tripulacionRepository;

    @Autowired
    private ReclutamientoRepository reclutamientoRepository;

    @Override
    public List<TripulacionDTO> listarTodos() {
        return tripulacionRepository.findAll().stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<TripulacionDTO> listarPorFiltros(Long id, String nombre, String barco) {
        List<TripulacionDTO> dtos = tripulacionRepository.buscarPorFiltros(id, nombre, barco, 1);
        for (TripulacionDTO dto : dtos) {
            dto.setNumeroMiembros(reclutamientoRepository.countMiembrosByTripulacionId(dto.getId()));
        }
        return dtos;
    }

    @Override
    public TripulacionDTO obtenerPorId(Long id) {
        Optional<TripulacionEntity> entity = tripulacionRepository.findById(id);
        return entity.map(this::toDTO).orElse(null);
    }

    @Override
    public Long registrar(String nombre, String barco) {
        TripulacionEntity entity = new TripulacionEntity();
        entity.setNombre(nombre);
        entity.setBarco(barco);
        entity.setEstaActiva(1);
        entity = tripulacionRepository.save(entity);
        return entity.getId();
    }

    @Override
    public Long actualizar(Long id, String nombre, String barco) {
        return tripulacionRepository.findById(id)
                .map(entity -> {
                    if (nombre != null && !nombre.trim().isEmpty()) {
                        entity.setNombre(nombre);
                    }
                    if (barco != null && !barco.trim().isEmpty()) {
                        entity.setBarco(barco);
                    }
                    tripulacionRepository.save(entity);
                    return entity.getId();
                })
                .orElse(null);
    }

    @Override
    public boolean borrar(Long id) {
        return tripulacionRepository.findById(id)
                .map(entity -> {
                    entity.setEstaActiva(0);
                    tripulacionRepository.save(entity);
                    return true;
                })
                .orElse(false);
    }

    private TripulacionDTO toDTO(TripulacionEntity entity) {
        Integer numeroMiembros = reclutamientoRepository.countMiembrosByTripulacionId(entity.getId());
        return new TripulacionDTO(
                entity.getId(),
                entity.getNombre(),
                entity.getBarco(),
                entity.getEstaActiva(),
                numeroMiembros
        );
    }
}
