package com.daw.onepiece.dtos;

public class TripulacionDTO {
	private Long id;
    private String nombre;
    private String barco;
    private Integer estaActiva;
    private String estado;
    private Integer numeroMiembros;

    // Constructor vacío
    public TripulacionDTO() {
    }

    // Constructor que usa la query JPQL (4 parámetros)
    public TripulacionDTO(Long id, String nombre, String barco, Integer estaActiva) {
        this.id = id;
        this.nombre = nombre;
        this.barco = barco;
        this.estaActiva = estaActiva;
        this.estado = (estaActiva != null && estaActiva == 1) ? "Activo" : "Inactivo";
        this.numeroMiembros = 0; // valor por defecto
    }

    // Constructor completo (5 parámetros)
    public TripulacionDTO(Long id, String nombre, String barco, Integer estaActiva, Integer numeroMiembros) {
        this(id, nombre, barco, estaActiva);
        this.numeroMiembros = numeroMiembros;
    }

    // Getters y Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getBarco() {
        return barco;
    }

    public void setBarco(String barco) {
        this.barco = barco;
    }

    public Integer getEstaActiva() {
        return estaActiva;
    }

    public void setEstaActiva(Integer estaActiva) {
        this.estaActiva = estaActiva;
    }

    public String getEstado() {
        return estado;
    }

    public Integer getNumeroMiembros() {
        return numeroMiembros;
    }

    public void setNumeroMiembros(Integer numeroMiembros) {
        this.numeroMiembros = numeroMiembros;
    }
}
