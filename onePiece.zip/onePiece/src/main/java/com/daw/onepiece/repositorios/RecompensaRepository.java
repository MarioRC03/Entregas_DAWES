package com.daw.onepiece.repositorios;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.daw.onepiece.dtos.RecompensaDTO;
import com.daw.onepiece.entities.PiratasEntity;
import com.daw.onepiece.entities.RecompensaEntity;
import com.daw.onepiece.entities.TripulacionEntity;

public interface RecompensaRepository extends CrudRepository<RecompensaEntity, Integer>{
	@Query("""
	        SELECT new com.daw.onepiece.dtos.RecompensaDTO(
	            r.id,
	            r.pirataId,
	            r.cantidad,
	            r.estaVigente,
	            p.nombre,
	            null
	        )
	        FROM RecompensaEntity r
	        JOIN PiratasEntity p ON r.pirataId = p.id
	        WHERE (:id IS NULL OR r.id = :id)
	          AND (:nombrePirata IS NULL OR p.nombre LIKE CONCAT('%', :nombrePirata, '%'))
	          AND (:cantidadMin IS NULL OR r.cantidad >= :cantidadMin)
	          AND (:estaVigente IS NULL OR r.estaVigente = :estaVigente)
	    """)
	    ArrayList<RecompensaDTO> buscarRecompensasPorFiltros(
	        @Param("id") Integer id,
	        @Param("nombrePirata") String nombrePirata,
	        @Param("cantidadMin") Long cantidadMin,
	        @Param("estaVigente") Integer estaVigente);

	    @Query("SELECT r FROM RecompensaEntity r WHERE r.pirataId = :pirataId AND r.estaVigente = 1")
	    List<RecompensaEntity> findVigentesByPirataId(@Param("pirataId") Integer pirataId);

	    // Para los desplegables
	    @Query("SELECT p FROM PiratasEntity p WHERE p.activo = 1")
	    List<PiratasEntity> findAllPiratasActivos();

	    // Método corregido (usa el nombre real del campo)
	    @Query("SELECT t FROM TripulacionEntity t WHERE t.estaActiva = 1")
	    List<TripulacionEntity> findAllTripulacionesActivas();
}
