package com.daw.onepiece.servicio.interfaces;

import java.util.List;

import com.daw.onepiece.dtos.TripulacionDTO;

public interface ITripulacionService {
	List<TripulacionDTO> listarTodos();

    List<TripulacionDTO> listarPorFiltros(Long id, String nombre, String barco);

    TripulacionDTO obtenerPorId(Long id);

    Long registrar(String nombre, String barco);

    Long actualizar(Long id, String nombre, String barco);

    boolean borrar(Long id);
}
