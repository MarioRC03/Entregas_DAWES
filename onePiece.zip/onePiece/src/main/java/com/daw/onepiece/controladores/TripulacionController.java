package com.daw.onepiece.controladores;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.daw.onepiece.dtos.MiembroTripulacionDTO;
import com.daw.onepiece.dtos.TripulacionDTO;
import com.daw.onepiece.entities.PiratasEntity;
import com.daw.onepiece.entities.ReclutamientoEntity;
import com.daw.onepiece.entities.TripulacionEntity;
import com.daw.onepiece.repositorios.PiratasRepository;
import com.daw.onepiece.repositorios.ReclutamientoRepository;
import com.daw.onepiece.repositorios.TripulacionRepository;
import com.daw.onepiece.servicio.interfaces.ITripulacionService;

@Controller
@RequestMapping("/tripulaciones")
public class TripulacionController {
	@Autowired
    private ITripulacionService tripulacionService;

    @Autowired
    private TripulacionRepository tripulacionRepository;

    @Autowired
    private PiratasRepository piratasRepository;

    @Autowired
    private ReclutamientoRepository reclutamientoRepository;

    @GetMapping("/listadoTripulaciones")
    public String mostrarFormularioListado(ModelMap model) {
        return "tripulaciones/listadoTripulaciones";
    }

    @PostMapping("/listadoTripulaciones")
    public String procesarListadoTripulaciones(
            @RequestParam(value = "nombre", required = false) String nombre,
            @RequestParam(value = "barco", required = false) String barco,
            @RequestParam(value = "estaActiva", required = false) String estaActivaStr,
            ModelMap model) {

        Integer estaActiva = (estaActivaStr != null && estaActivaStr.equals("1")) ? 1 : null;

        List<TripulacionDTO> lista = tripulacionService.listarPorFiltros(null, nombre, barco);

        model.addAttribute("lista", lista);
        return "tripulaciones/listadoTripulaciones";
    }

    @GetMapping("/insertarTripulacion")
    public String mostrarFormularioInsertar(ModelMap model) {
        return "tripulaciones/insertarTripulacion";
    }

    @PostMapping("/insertarTripulacion")
    public String procesarInsertarTripulacion(
            @RequestParam("nombre") String nombre,
            @RequestParam("barco") String barco,
            @RequestParam(value = "estaActiva", required = false) String estaActivaStr,
            ModelMap model) {

        Integer estaActiva = (estaActivaStr != null && estaActivaStr.equals("1")) ? 1 : 0;

        Long idNuevo = tripulacionService.registrar(nombre, barco);

        int resultado = (idNuevo != null && idNuevo > 0) ? 1 : 0;

        model.addAttribute("resultado", resultado);
        return "tripulaciones/insertarTripulacion";
    }

    @GetMapping("/formularioActualizarTripulaciones")
    public String mostrarFormularioActualizar(ModelMap model) {
        return "tripulaciones/actualizarTripulaciones";
    }

    @PostMapping("/formularioActualizarTripulaciones")
    public String buscarParaActualizar(
            @RequestParam(value = "id", required = false) Long id,
            @RequestParam(value = "nombre", required = false) String nombre,
            @RequestParam(value = "barco", required = false) String barco,
            @RequestParam(value = "estaActiva", required = false) String estaActivaStr,
            ModelMap model) {

        Integer estaActiva = (estaActivaStr != null && estaActivaStr.equals("1")) ? 1 : null;

        List<TripulacionDTO> lista = tripulacionService.listarPorFiltros(id, nombre, barco);

        model.addAttribute("lista", lista);
        return "tripulaciones/actualizarTripulaciones";
    }

    @PostMapping("/actualizarTripulacion")
    public String procesarActualizarTripulacion(
            @RequestParam("id") Long id,
            @RequestParam(value = "nombre", required = false) String nombre,
            @RequestParam(value = "barco", required = false) String barco,
            @RequestParam(value = "estaActiva", required = false) String estaActivaStr,
            ModelMap model) {

        Integer estaActiva = null;
        if (estaActivaStr != null && !estaActivaStr.isEmpty()) {
            estaActiva = estaActivaStr.equals("1") ? 1 : 0;
        }

        Long idActualizado = tripulacionService.actualizar(id, nombre, barco);

        int resultado = (idActualizado != null) ? 1 : 0;

        model.addAttribute("resultado", resultado);
        return "tripulaciones/actualizarTripulaciones";
    }

    @GetMapping("/formularioBorrarTripulaciones")
    public String mostrarFormularioBorrar(ModelMap model) {
        return "tripulaciones/borrarTripulaciones";
    }

    @PostMapping("/formularioBorrarTripulaciones")
    public String buscarParaBorrar(
            @RequestParam(value = "id", required = false) Long id,
            @RequestParam(value = "nombre", required = false) String nombre,
            ModelMap model) {

        List<TripulacionDTO> lista = tripulacionService.listarPorFiltros(id, nombre, null);

        model.addAttribute("lista", lista);
        return "tripulaciones/borrarTripulaciones";
    }

    @PostMapping("/borrarTripulacion")
    public String procesarBorrarTripulacion(
            @RequestParam("id") Long id,
            ModelMap model) {

        boolean exito = tripulacionService.borrar(id);
        int resultado = exito ? 1 : 0;

        model.addAttribute("resultado", resultado);
        return "tripulaciones/borrarTripulaciones";
    }

    @GetMapping("/detallesTripulacion")
    public String mostrarDetallesTripulacion(
            @RequestParam("id") Long id,
            ModelMap model) {

        TripulacionDTO tripulacion = tripulacionService.obtenerPorId(id);
        if (tripulacion == null) {
            return "redirect:/tripulaciones/listadoTripulaciones";
        }

        List<ReclutamientoEntity> miembrosEntities = reclutamientoRepository.findMiembrosActualesByTripulacionId(id);
        List<MiembroTripulacionDTO> miembros = miembrosEntities.stream()
                .map(r -> new MiembroTripulacionDTO(
                        r.getPirata().getId(),
                        r.getId(),
                        r.getPirata().getNombre(),
                        r.getRol(),
                        r.getPirata().getFrutaDiablo()
                ))
                .collect(Collectors.toList());

        List<PiratasEntity> piratasActivos = piratasRepository.findAllActivos();

        model.addAttribute("tripulacion", tripulacion);
        model.addAttribute("miembros", miembros);
        model.addAttribute("piratasActivos", piratasActivos);

        return "tripulaciones/detallesTripulacion";
    }

    @PostMapping("/agregarMiembro")
    public String agregarMiembro(
            @RequestParam("idTripulacion") Long idTripulacion,
            @RequestParam("idPirata") Integer idPirata,
            @RequestParam("rol") String rol,
            RedirectAttributes redirectAttrs) {

        TripulacionEntity tripulacion = tripulacionRepository.findById(idTripulacion).orElse(null);
        PiratasEntity pirata = piratasRepository.findById(idPirata).orElse(null);

        if (tripulacion == null || pirata == null) {
            redirectAttrs.addFlashAttribute("error", "Tripulación o pirata no encontrado");
            return "redirect:/tripulaciones/detallesTripulacion?id=" + idTripulacion;
        }

        reclutamientoRepository.desactivarReclutamientosDelPirata(idPirata);

        ReclutamientoEntity nuevoReclutamiento = new ReclutamientoEntity(pirata, tripulacion, rol, 1);
        reclutamientoRepository.save(nuevoReclutamiento);

        redirectAttrs.addFlashAttribute("success", "Miembro agregado correctamente");
        return "redirect:/tripulaciones/detallesTripulacion?id=" + idTripulacion;
    }

    @PostMapping("/eliminarMiembro")
    public String eliminarMiembro(
            @RequestParam("idPirata") Integer idPirata,
            @RequestParam("idTripulacion") Long idTripulacion,
            RedirectAttributes redirectAttrs) {

        List<ReclutamientoEntity> reclutamientos = reclutamientoRepository.findMiembrosActualesByTripulacionId(idTripulacion);
        ReclutamientoEntity reclutamiento = reclutamientos.stream()
                .filter(r -> r.getPirata().getId().equals(idPirata))
                .findFirst()
                .orElse(null);

        if (reclutamiento == null) {
            redirectAttrs.addFlashAttribute("error", "Miembro no encontrado");
            return "redirect:/tripulaciones/detallesTripulacion?id=" + idTripulacion;
        }

        reclutamientoRepository.eliminarMiembro(reclutamiento.getId());

        redirectAttrs.addFlashAttribute("success", "Miembro eliminado correctamente");
        return "redirect:/tripulaciones/detallesTripulacion?id=" + idTripulacion;
    }
}
