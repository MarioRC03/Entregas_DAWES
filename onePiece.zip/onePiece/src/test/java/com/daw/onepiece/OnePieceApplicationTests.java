package com.daw.onepiece;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnePieceApplicationTests {

	@Test
	void contextLoads() {
	}

}
