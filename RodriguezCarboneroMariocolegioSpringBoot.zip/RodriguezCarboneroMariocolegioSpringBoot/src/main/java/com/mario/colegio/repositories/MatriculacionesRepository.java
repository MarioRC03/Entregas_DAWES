package com.mario.colegio.repositories;

import java.util.ArrayList;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.mario.colegio.dtos.AsignaturaDTO;
import com.mario.colegio.dtos.MatriculacionesDTO;
import com.mario.colegio.entities.AsignaturaEntity;
import com.mario.colegio.entities.MatriculacionesEntity;

public interface MatriculacionesRepository extends CrudRepository<MatriculacionesEntity, Integer> {
	 @Query("""
        SELECT new com.mario.colegio.dtos.MatriculacionesDTO(
            m.id,
            al.id,
            al.nombre,
            a.id,
            a.nombre,
            m.fecha,
            m.tasa,
            m.activo
        )
        FROM MatriculacionesEntity m
        JOIN m.asignatura a
        JOIN m.alumno al
        WHERE (:id IS NULL OR m.id = :id)
          AND (:idAsignatura IS NULL OR a.id = :idAsignatura)
          AND (:nombreAsignatura IS NULL OR a.nombre LIKE CONCAT('%', :nombreAsignatura, '%'))
          AND (:idAlumno IS NULL OR al.id = :idAlumno)
          AND (:nombreAlumno IS NULL OR al.nombre LIKE CONCAT('%', :nombreAlumno, '%'))
          AND (:fecha IS NULL OR m.fecha = :fecha)
          AND (:tasa IS NULL OR m.tasa >= :tasa)
          AND (:activo IS NULL OR m.activo = :activo)
        """)
    ArrayList<MatriculacionesDTO> buscarMatriculacionporIDyNombre(
        @Param("id") Integer id,
        @Param("idAsignatura") Integer idAsignatura,
        @Param("nombreAsignatura") String nombreAsignatura,
        @Param("idAlumno") Integer idAlumno,
        @Param("nombreAlumno") String nombreAlumno,
        @Param("fecha") String fecha,
        @Param("tasa") Double tasa,
        @Param("activo") Integer activo
    );

}
