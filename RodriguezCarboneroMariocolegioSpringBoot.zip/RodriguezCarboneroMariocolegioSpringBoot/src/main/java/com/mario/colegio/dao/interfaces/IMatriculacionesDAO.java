package com.mario.colegio.dao.interfaces;

import java.sql.SQLException;
import java.util.ArrayList;

import com.mario.colegio.dtos.MatriculacionesDTO;



public interface IMatriculacionesDAO {
	int insertarMatriculacion(String idAsignatura, String idAlumno, String fecha, Double tasa);

    int actualizarMatriculacion(Integer id, String idAsignatura, String idAlumno, String fecha, Double tasa);

    int borrarMatriculacion(Integer id);

    ArrayList<MatriculacionesDTO> obtenerMatriculacionesPorFiltros(String nombreAsignatura, String nombreAlumno,
    		String fecha, Integer activo);

    double obtenerTasaAsignatura(String idAsignatura);
}
