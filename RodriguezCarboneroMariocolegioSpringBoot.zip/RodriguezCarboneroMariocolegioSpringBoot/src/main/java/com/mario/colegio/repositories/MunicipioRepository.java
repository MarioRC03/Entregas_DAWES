package com.mario.colegio.repositories;

import org.springframework.data.repository.CrudRepository;

import com.mario.colegio.entities.MunicipioEntity;

public interface MunicipioRepository extends CrudRepository<MunicipioEntity,Integer>{

}
