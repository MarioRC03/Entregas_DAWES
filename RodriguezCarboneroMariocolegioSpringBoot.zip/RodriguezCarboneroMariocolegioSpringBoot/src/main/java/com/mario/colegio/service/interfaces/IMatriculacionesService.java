package com.mario.colegio.service.interfaces;

import java.util.ArrayList;

import com.mario.colegio.dtos.MatriculacionesDTO;

public interface IMatriculacionesService {
	public double calcularTasa(String idAlumno, String idAsignatura);

	int insertarMatriculacion(String idAsignatura, String idAlumno,
			String fecha, Double tasa);

	ArrayList<MatriculacionesDTO> obtenerMatriculacionesPorFiltros(String nombreAsignatura, String nombreAlumno,
			String fecha, Integer activo);

	int actualizarMatriculacion(Integer id, String idAsignatura, String idAlumno,
			String fecha, Double tasa);

	int borrarMatriculacion(Integer id);
}
