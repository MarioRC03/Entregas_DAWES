package com.mario.colegio.controladores;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mario.colegio.dao.interfaces.IDesplegableDAO;
import com.mario.colegio.dtos.FaltasDTO;
import com.mario.colegio.dtos.MatriculacionesDTO;
import com.mario.colegio.service.interfaces.IMatriculacionesService;

@Controller
@RequestMapping("/matriculaciones")
public class MatriculacionesController {

    @Autowired
    private IMatriculacionesService matriculacionesService;

    @Autowired
    private IDesplegableDAO desplegables;

    private final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    // ========================= LISTADO =========================
    @GetMapping("/listadoMatriculaciones")
    public String formularioListadoMatriculaciones(ModelMap model) {
        model.addAttribute("desplegableAlumnos", desplegables.desplegableAlumnos());
        model.addAttribute("desplegableAsignaturas", desplegables.desplegableAsignaturas());
        return "matriculaciones/listadoMatriculaciones";
    }

    @PostMapping("/listadoMatriculaciones")
    public String listadoMatriculaciones(
            @RequestParam(value = "nombreAsignatura", required = false) String nombreAsignatura,
            @RequestParam(value = "nombreAlumno", required = false) String nombreAlumno,
            @RequestParam(value = "fecha", required = false) String fecha,
            ModelMap model) {

        LocalDate fechaFiltro = null;
        if (fecha != null && !fecha.isBlank()) {
            fechaFiltro = LocalDate.parse(fecha, dateFormatter);
        }

        ArrayList<MatriculacionesDTO> lista = matriculacionesService.obtenerMatriculacionesPorFiltros(
                nombreAsignatura,
                nombreAlumno,
                fechaFiltro != null ? fechaFiltro.toString() : null,
                null);

        model.addAttribute("lista", lista);
        model.addAttribute("desplegableAlumnos", desplegables.desplegableAlumnos());
        model.addAttribute("desplegableAsignaturas", desplegables.desplegableAsignaturas());

        return "matriculaciones/listadoMatriculaciones"; // Mostrar listado en la página de actualizar
    }

    // ========================= INSERTAR =========================
    @GetMapping("/insertarMatriculacion")
    public String formularioInsertarMatriculacion(ModelMap model) {
        model.addAttribute("desplegableAlumnos", desplegables.desplegableAlumnos());
        model.addAttribute("desplegableAsignaturas", desplegables.desplegableAsignaturas());
        return "matriculaciones/insertarMatriculacion";
    }

    @PostMapping("/insertarMatriculacion")
    public String insertarMatriculacion(@RequestParam("idAsignatura") String idAsignatura,
                                        @RequestParam("idAlumno") String idAlumno,
                                        @RequestParam("fecha") String fecha,
                                        @RequestParam("tasa") Double tasa,
                                        ModelMap model) {

        int resultado = matriculacionesService.insertarMatriculacion(idAsignatura, idAlumno, fecha, tasa);
        model.addAttribute("resultado", resultado);
        model.addAttribute("desplegableAlumnos", desplegables.desplegableAlumnos());
        model.addAttribute("desplegableAsignaturas", desplegables.desplegableAsignaturas());

        return "matriculaciones/insertarMatriculacion";
    }

    // ========================= ACTUALIZAR =========================
    @GetMapping("/formularioActualizarMatriculaciones")
    public String formularioActualizarMatriculaciones(ModelMap model) {
        model.addAttribute("desplegableAlumnos", desplegables.desplegableAlumnos());
        model.addAttribute("desplegableAsignaturas", desplegables.desplegableAsignaturas());
        model.addAttribute("lista", new ArrayList<MatriculacionesDTO>()); // Inicializar lista vacía
        return "matriculaciones/actualizarMatriculaciones";
    }

    // ========================= FILTRAR MATRICULACIONES PARA ACTUALIZAR =========================
    @PostMapping("/formularioActualizarMatriculacion")
    public String formularioActualizarMatriculacion(
            @RequestParam(value = "nombreAlumno", required = false) String nombreAlumno,
            @RequestParam(value = "nombreAsignatura", required = false) String nombreAsignatura,
            @RequestParam(value = "fecha", required = false) String fecha,
            ModelMap model) {

        LocalDate fechaFiltro = null;
        if (fecha != null && !fecha.isBlank()) {
            fechaFiltro = LocalDate.parse(fecha, dateFormatter);
        }

        ArrayList<MatriculacionesDTO> lista = matriculacionesService.obtenerMatriculacionesPorFiltros(
                nombreAsignatura,
                nombreAlumno,
                fechaFiltro != null ? fechaFiltro.toString() : null,
                null);

        model.addAttribute("lista", lista);
        model.addAttribute("desplegableAlumnos", desplegables.desplegableAlumnos());
        model.addAttribute("desplegableAsignaturas", desplegables.desplegableAsignaturas());

        return "matriculaciones/actualizarMatriculaciones";
    }

    @PostMapping("/actualizarMatriculacion")
    public String actualizarMatriculacion(@RequestParam("id") Integer id,
                                          @RequestParam("idAsignatura") String idAsignatura,
                                          @RequestParam("idAlumno") String idAlumno,
                                          @RequestParam("fecha") String fecha,
                                          @RequestParam("tasa") Double tasa,
                                          ModelMap model) {

        int resultado = matriculacionesService.actualizarMatriculacion(id, idAsignatura, idAlumno, fecha, tasa);
        model.addAttribute("resultado", resultado);
        model.addAttribute("desplegableAlumnos", desplegables.desplegableAlumnos());
        model.addAttribute("desplegableAsignaturas", desplegables.desplegableAsignaturas());
        model.addAttribute("lista", new ArrayList<MatriculacionesDTO>()); // limpiar listado tras actualizar

        return "matriculaciones/actualizarMatriculaciones";
    }

 // ========================= BORRAR =========================
    @GetMapping("/formularioBorrarMatriculaciones")
    public String formularioBorrarMatriculaciones(ModelMap model) {
        // Inicializamos la lista vacía para mostrar en el formulario
        model.addAttribute("desplegableAlumnos", desplegables.desplegableAlumnos());
        model.addAttribute("desplegableAsignaturas", desplegables.desplegableAsignaturas());
        model.addAttribute("lista", new ArrayList<MatriculacionesDTO>());
        return "matriculaciones/borrarMatriculaciones";
    }

    @PostMapping("/formularioBorrarMatriculaciones")
    public String filtrarMatriculacionesParaBorrar(
            @RequestParam(value = "nombreAlumno", required = false) String nombreAlumno,
            @RequestParam(value = "nombreAsignatura", required = false) String nombreAsignatura,
            @RequestParam(value = "fecha", required = false) String fecha,
            ModelMap model) {

        LocalDate fechaFiltro = null;
        if (fecha != null && !fecha.isBlank()) {
            fechaFiltro = LocalDate.parse(fecha, dateFormatter);
        }

        // Obtenemos la lista filtrada de matriculaciones
        ArrayList<MatriculacionesDTO> lista = matriculacionesService.obtenerMatriculacionesPorFiltros(
                nombreAsignatura,
                nombreAlumno,
                fechaFiltro != null ? fechaFiltro.toString() : null,
                null);

        model.addAttribute("lista", lista);
        model.addAttribute("desplegableAlumnos", desplegables.desplegableAlumnos());
        model.addAttribute("desplegableAsignaturas", desplegables.desplegableAsignaturas());

        return "matriculaciones/borrarMatriculaciones";
    }

    @PostMapping("/borrarMatriculacion")
    public String borrarMatriculacion(@RequestParam("id") Integer id, ModelMap model) {
        int resultado = matriculacionesService.borrarMatriculacion(id);
        model.addAttribute("resultado", resultado);

        // Recargamos los desplegables y limpiamos la lista para volver a la página
        model.addAttribute("desplegableAlumnos", desplegables.desplegableAlumnos());
        model.addAttribute("desplegableAsignaturas", desplegables.desplegableAsignaturas());
        model.addAttribute("lista", new ArrayList<MatriculacionesDTO>());

        return "matriculaciones/borrarMatriculaciones";
    }

}
