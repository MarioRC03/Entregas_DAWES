package com.mario.colegio.repositories;

import java.util.ArrayList;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.mario.colegio.dtos.AsignaturaDTO;
import com.mario.colegio.dtos.FaltasDTO;
import com.mario.colegio.entities.AsignaturaEntity;
import com.mario.colegio.entities.FaltasEntity;

public interface FaltasRepository extends CrudRepository<FaltasEntity, Integer> {
	@Query("""
			SELECT new com.mario.colegio.dtos.FaltasDTO(
			    f.idFalta,
			    a.id,
			    a.nombre,
			    s.id,
			    s.nombre,
			    f.fecha,
			    f.justificada
			)
			FROM FaltasEntity f
			JOIN f.alumno a
			JOIN f.asignaturas s
			WHERE
			    (:nombreAlumno IS NULL OR a.nombre LIKE CONCAT('%', :nombreAlumno, '%'))
			AND (:asignatura IS NULL OR s.nombre LIKE CONCAT('%', :asignatura, '%'))
			AND (:fecha IS NULL OR f.fecha = :fecha)
			AND f.justificada = :justificada
			""")
	ArrayList<FaltasDTO> buscarFaltaporIDyNombre(@Param("nombreAlumno") String nombreAlumno,
			@Param("asignatura") String asignatura, @Param("fecha") String fecha,
			@Param("justificada") Integer justificada);

}