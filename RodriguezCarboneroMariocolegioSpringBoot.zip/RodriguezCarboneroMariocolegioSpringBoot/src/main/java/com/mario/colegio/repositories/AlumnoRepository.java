package com.mario.colegio.repositories;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.mario.colegio.dtos.AlumnoDTO;
import com.mario.colegio.entities.AlumnoEntity;

public interface AlumnoRepository extends CrudRepository<AlumnoEntity,Integer>{

	@Query("select new com.mario.colegio.dtos.AlumnoDTO(a.id,a.nombre,a.apellidos,a.municipio.nombre,a.municipio.idMunicipio,a.famNumerosa,a.activo) "
			+ "FROM com.mario.colegio.entities.AlumnoEntity a "
			+ "WHERE CAST (a.id AS STRING) LIKE CONCAT ('%',:id,'%') "
			+ "AND a.nombre LIKE CONCAT ('%',:nombre,'%') "
			+ "AND a.apellidos LIKE CONCAT ('%',:apellidos,'%') "
			+ "AND a.activo = :activo "
			+ "AND a.famNumerosa = :famNumerosa")
			ArrayList<AlumnoDTO>buscaAlumnoporIDyNombre(@Param("id") Integer id,
			@Param("nombre") String nombre,
			@Param("apellidos") String apellidos,
			@Param("activo") Integer activo,
			@Param("famNumerosa") Integer familiaNumerosa);
}
