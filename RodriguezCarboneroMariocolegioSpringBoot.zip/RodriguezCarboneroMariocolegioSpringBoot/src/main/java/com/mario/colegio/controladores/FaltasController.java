package com.mario.colegio.controladores;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mario.colegio.dao.interfaces.IDesplegableDAO;
import com.mario.colegio.dtos.FaltasDTO;
import com.mario.colegio.repositories.AsignaturaRepository;
import com.mario.colegio.repositories.FaltasRepository;
import com.mario.colegio.repositories.MunicipioRepository;
import com.mario.colegio.service.interfaces.IAsignaturasService;
import com.mario.colegio.service.interfaces.IFaltasService;

@Controller
@RequestMapping("/faltas")
public class FaltasController {

	 @Autowired
	    private IFaltasService faltasService;

	    @Autowired
	    IDesplegableDAO desplegables;

	    // LISTADO
	    @GetMapping("/listadoFaltas")
	    public String formularioListadoFaltas(ModelMap model) {
	        // Agregamos desplegables para filtro
	        model.addAttribute("desplegableAlumnos", desplegables.desplegableAlumnos());
	        model.addAttribute("desplegableAsignaturas", desplegables.desplegableAsignaturas());
	        return "faltas/listadoFaltas";
	    }

	    @PostMapping("/listadoFaltas")
	    public String listadoFaltas(@RequestParam(value = "nombreAlumno", required = false) String nombreAlumno,
	            @RequestParam(value = "asignatura", required = false) String asignatura,
	            @RequestParam(value = "fecha", required = false) String fecha,
	            @RequestParam(value = "justificada", required = false) String justificada, ModelMap model) {

	        Integer just = (justificada != null && justificada.equals("1")) ? 1 : 0;
	        if (fecha != null && fecha.trim().isEmpty()) fecha = null;

	        ArrayList<FaltasDTO> listaFaltas = faltasService.obtenerFaltasPorFiltros(nombreAlumno, asignatura, fecha, just);
	        model.addAttribute("lista", listaFaltas);

	        // Reagregamos los desplegables
	        model.addAttribute("desplegableAlumnos", desplegables.desplegableAlumnos());
	        model.addAttribute("desplegableAsignaturas", desplegables.desplegableAsignaturas());

	        return "faltas/listadoFaltas";
	    }

	    // INSERTAR
	    @GetMapping("/insertarFalta")
	    public String formularioInsertarFalta(ModelMap model) {
	        model.addAttribute("desplegableAlumnos", desplegables.desplegableAlumnos());
	        model.addAttribute("desplegableAsignaturas", desplegables.desplegableAsignaturas());
	        return "faltas/insertarFalta";
	    }

	    @PostMapping("/insertarFalta")
	    public String insertarFalta(
	            @RequestParam(value = "idAlumno", required = false) Integer idAlumno,
	            @RequestParam(value = "idAsignatura", required = false) Integer idAsignatura,
	            @RequestParam(value = "fecha", required = false) String fecha,
	            @RequestParam(value = "justificada", required = false) Integer justificada,
	            ModelMap model) {

	        // Reagregamos desplegables siempre
	        model.addAttribute("desplegableAlumnos", desplegables.desplegableAlumnos());
	        model.addAttribute("desplegableAsignaturas", desplegables.desplegableAsignaturas());

	        // Validaciones: alumno y asignatura no pueden ser null
	        if (idAlumno == null || idAsignatura == null) {
	            model.addAttribute("error", "Debes seleccionar un alumno y una asignatura.");
	            return "faltas/insertarFalta";
	        }

	        // Limpieza de fecha vacía
	        if (fecha != null && fecha.trim().isEmpty()) fecha = null;

	        // Llamamos al servicio
	        int resultado = faltasService.insertarFalta(idAlumno, idAsignatura, fecha, justificada);
	        model.addAttribute("resultado", resultado);

	        return "faltas/insertarFalta";
	    }

	    // ACTUALIZAR
	    @GetMapping("/formularioActualizarFaltas")
	    public String formularioModificarFaltas(ModelMap model) {
	        model.addAttribute("desplegableAlumnos", desplegables.desplegableAlumnos());
	        model.addAttribute("desplegableAsignaturas", desplegables.desplegableAsignaturas());
	        return "faltas/actualizarFaltas";
	    }

	    @PostMapping("/formularioActualizarFaltas")
	    public String formularioModificarFaltas(@RequestParam(value = "nombreAlumno", required = false) String nombreAlumno,
	            @RequestParam(value = "asignatura", required = false) String asignatura,
	            @RequestParam(value = "fecha", required = false) String fecha,
	            @RequestParam(value = "justificada", required = false) String justificada, ModelMap model) {

	        Integer just = (justificada != null && justificada.equals("1")) ? 1 : 0;
	        if (fecha != null && fecha.trim().isEmpty()) fecha = null;

	        ArrayList<FaltasDTO> listaFaltas = faltasService.obtenerFaltasPorFiltros(nombreAlumno, asignatura, fecha, just);
	        model.addAttribute("lista", listaFaltas);

	        model.addAttribute("desplegableAlumnos", desplegables.desplegableAlumnos());
	        model.addAttribute("desplegableAsignaturas", desplegables.desplegableAsignaturas());

	        return "faltas/actualizarFaltas";
	    }

	    @PostMapping("/actualizarFalta")
	    public String modificarFalta(@RequestParam(value = "idFalta", required = false) Integer idFalta,
	            @RequestParam(value = "idAlumno", required = false) Integer idAlumno,
	            @RequestParam(value = "idAsignatura", required = false) Integer idAsignatura,
	            @RequestParam(value = "fecha", required = false) String fecha,
	            @RequestParam(value = "justificada", required = false) String justificada, ModelMap model) {

	        Integer just = (justificada != null && justificada.equals("1")) ? 1 : 0;
	        if (fecha != null && fecha.trim().isEmpty()) fecha = null;

	        int resultado = faltasService.actualizarFalta(idFalta, idAlumno, idAsignatura, fecha, just);
	        model.addAttribute("resultado", resultado);

	        model.addAttribute("desplegableAlumnos", desplegables.desplegableAlumnos());
	        model.addAttribute("desplegableAsignaturas", desplegables.desplegableAsignaturas());

	        return "faltas/actualizarFaltas";
	    }

	    // BORRAR
	    @GetMapping("/formularioBorrarFaltas")
	    public String getFormularioBorrarFaltas(ModelMap model) {
	        model.addAttribute("desplegableAlumnos", desplegables.desplegableAlumnos());
	        model.addAttribute("desplegableAsignaturas", desplegables.desplegableAsignaturas());
	        return "faltas/borrarFaltas";
	    }

	    @PostMapping("/formularioBorrarFaltas")
	    public String formularioBorrarFaltas(@RequestParam(value = "nombreAlumno", required = false) String nombreAlumno,
	            @RequestParam(value = "asignatura", required = false) String asignatura,
	            @RequestParam(value = "fecha", required = false) String fecha,
	            @RequestParam(value = "justificada", required = false) String justificada, ModelMap model) {

	        Integer just = (justificada != null && justificada.equals("1")) ? 1 : 0;
	        if (fecha != null && fecha.trim().isEmpty()) fecha = null;

	        ArrayList<FaltasDTO> listaFaltas = faltasService.obtenerFaltasPorFiltros(nombreAlumno, asignatura, fecha, just);
	        model.addAttribute("lista", listaFaltas);

	        model.addAttribute("desplegableAlumnos", desplegables.desplegableAlumnos());
	        model.addAttribute("desplegableAsignaturas", desplegables.desplegableAsignaturas());

	        return "faltas/borrarFaltas";
	    }

	    @PostMapping("/borrarFalta")
	    public String borrarFalta(@RequestParam("idFalta") Integer idFalta, ModelMap model) {
	        Integer resultado = faltasService.borrarFalta(idFalta);
	        model.addAttribute("resultado", resultado);

	        model.addAttribute("desplegableAlumnos", desplegables.desplegableAlumnos());
	        model.addAttribute("desplegableAsignaturas", desplegables.desplegableAsignaturas());

	        return "faltas/borrarFaltas";
	    }
}
