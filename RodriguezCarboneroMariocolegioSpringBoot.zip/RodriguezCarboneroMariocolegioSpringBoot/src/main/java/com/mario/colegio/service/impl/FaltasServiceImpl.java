package com.mario.colegio.service.impl;

import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mario.colegio.dao.interfaces.IAlumnosDAO;
import com.mario.colegio.dao.interfaces.IFaltasDAO;
import com.mario.colegio.dtos.FaltasDTO;
import com.mario.colegio.service.interfaces.IFaltasService;

@Service
public class FaltasServiceImpl implements IFaltasService{
	
	@Autowired
    private IFaltasDAO faltasDAO;

    @Override
    public ArrayList<FaltasDTO> obtenerFaltas() throws SQLException {
        return faltasDAO.obtenerTodasFaltas();
    }

    @Override
    public ArrayList<FaltasDTO> obtenerFaltasPorFiltros(String nombreAlumno, String asignatura, String fecha,
            Integer justificada) {
        return faltasDAO.obtenerFaltasPorFiltros(nombreAlumno, asignatura, fecha, justificada);
    }

    @Override
    public int insertarFalta(Integer idAlumno, Integer idAsignatura, String fecha, Integer justificada) {
        return faltasDAO.insertarFalta(idAlumno, idAsignatura, fecha, justificada);
    }

    @Override
    public int actualizarFalta(Integer idFalta, Integer idAlumno, Integer idAsignatura, String fecha,
            Integer justificada) {
        return faltasDAO.actualizarFalta(idFalta, idAlumno, idAsignatura, fecha, justificada);
    }

    @Override
    public int borrarFalta(Integer idFalta) {
        return faltasDAO.borrarFalta(idFalta);
    }
}
