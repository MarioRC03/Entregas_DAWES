package com.mario.colegio.controladores;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mario.colegio.dao.interfaces.IDesplegableDAO;
import com.mario.colegio.dtos.AsignaturaDTO;
import com.mario.colegio.repositories.AsignaturaRepository;
import com.mario.colegio.repositories.MunicipioRepository;
import com.mario.colegio.service.interfaces.IAsignaturasService;

@Controller
@RequestMapping("/asignaturas")
public class AsignaturasController {

	@Autowired
    private IAsignaturasService asignaturasService;
    @Autowired
	IDesplegableDAO desplegables;
	@Autowired
	AsignaturaRepository asignaturaRepository;
	@Autowired
	MunicipioRepository municipioRepository;
    
    // LISTADO
    @GetMapping("/listadoAsignaturas")
    public String formularioListadoAsignaturas() {
        return "asignaturas/listadoAsignaturas";
    }
    
    @PostMapping("/listadoAsignaturas")
    public String listadoAsignaturas(
            @RequestParam(value = "id", required = false) Integer id,
            @RequestParam(value = "nombre", required = false) String nombre,
            @RequestParam(value = "curso", required = false) String curso,
            @RequestParam(value = "tasa", required = false) Double tasa,
            @RequestParam(value = "activo", required = false) String activo,
            ModelMap model) {
        
        Integer act = (activo != null && activo.equals("1")) ? 1 : 0;
        
        ArrayList<AsignaturaDTO> listaAsignaturas = asignaturasService
                .obtenerAsignaturasPorFiltros(id, nombre, curso, tasa, act);
        
        model.addAttribute("lista", listaAsignaturas);
        return "asignaturas/listadoAsignaturas";
    }
    
    // INSERTAR - CON id
    @GetMapping("/insertarAsignatura")
    public String formularioInsertarAsignatura() {
        return "asignaturas/insertarAsignatura";
    }
    
    @PostMapping("/insertarAsignatura")
    public String insertarAsignatura(
            @RequestParam(value="id",required=false) Integer id, 
            @RequestParam("nombre") String nombre,
            @RequestParam("curso") String curso,
            @RequestParam("tasa") Double tasa,
            @RequestParam("activo") Integer activo,
            ModelMap model) {
        
        
        int resultado = asignaturasService.insertarAsignatura(id, nombre, curso, tasa,activo);
        model.addAttribute("resultado", resultado);
        
        return "asignaturas/insertarAsignatura";
    }
    
   
    @GetMapping("/formularioActualizarAsignaturas")
    public String formularioModificarAsignaturas() {
        return "asignaturas/actualizarAsignaturas";
    }
    
    @PostMapping("/formularioActualizarAsignaturas")
    public String formularioModificarAsignaturas(
            @RequestParam(value = "id", required = false) int id,
            @RequestParam(value = "nombre", required = false) String nombre,
            @RequestParam(value = "curso", required = false) String curso,
            @RequestParam(value = "tasa", required = false) Double tasa,
            @RequestParam(value = "activo", required = false) String activo,
            ModelMap model) {
        
        Integer act = (activo != null && activo.equals("1")) ? 1 : 0;
        
        ArrayList<AsignaturaDTO> listaAsignaturas = asignaturasService
                .obtenerAsignaturasPorFiltros(id, nombre, curso, tasa, act);
        
        model.addAttribute("lista", listaAsignaturas);
        return "asignaturas/actualizarAsignaturas";
    }
    
    @PostMapping("/actualizarAsignatura")
    public String modificarAsignatura(
            @RequestParam("id") Integer id,
            @RequestParam("nombre") String nombre,
            @RequestParam("curso") String curso,
            @RequestParam("tasa") Double tasa,
            @RequestParam(value = "activo", required = false) String activo,
            ModelMap model) {
        
        Integer act = (activo != null && activo.equals("1")) ? 1 : 0;
        
        int resultado = asignaturasService.actualizarAsignatura(id, nombre, curso, tasa, act);
        model.addAttribute("resultado", resultado);
        
        return "asignaturas/actualizarAsignaturas";
    }
    
  
    @GetMapping("/formularioBorrarAsignaturas")
    public String getFormularioBorrarAsignaturas() {
        return "asignaturas/borrarAsignaturas";
    }
    
    @PostMapping("/formularioBorrarAsignaturas")
    public String formularioBorrarAsignaturas(
            @RequestParam(value = "id", required = false) Integer id,
            @RequestParam(value = "nombre", required = false) String nombre,
            @RequestParam(value = "curso", required = false) String curso,
            @RequestParam(value = "tasa", required = false) Double tasa,
            @RequestParam(value = "activo", required = false) String activo,
            ModelMap model) {
        
        Integer act = (activo != null && activo.equals("1")) ? 1 : 0;
        
        ArrayList<AsignaturaDTO> listaAsignaturas = asignaturasService
                .obtenerAsignaturasPorFiltros(id, nombre, curso, tasa, act);
        
        model.addAttribute("lista", listaAsignaturas);
        return "asignaturas/borrarAsignaturas";
    }
    
    @PostMapping("/borrarAsignatura")
    public String borrarAsignatura(@RequestParam("id") Integer id, ModelMap model) {
    	Integer resultado = asignaturasService.borrarAsignatura(id);
        model.addAttribute("resultado", resultado);
        return "asignaturas/borrarAsignaturas";
    }
}
