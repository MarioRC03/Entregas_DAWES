package com.mario.colegio.dtos;

public class MatriculacionesDTO {
	private int id;
	private int idAlumno;
	private String nombreAlumno;
	private int idAsignatura;
	private String nombreAsignatura;
	private String fecha; // ⚠️ Ahora String
	private Double tasa;
	private int activo;

	public MatriculacionesDTO(int id, int idAlumno, String nombreAlumno, int idAsignatura, String nombreAsignatura,
			String fecha, Double tasa, int activo) {
		this.id = id;
		this.idAlumno = idAlumno;
		this.nombreAlumno = nombreAlumno;
		this.idAsignatura = idAsignatura;
		this.nombreAsignatura = nombreAsignatura;
		this.fecha = fecha;
		this.tasa = tasa;
		this.activo = activo;
	}

	// Getters y setters
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getIdAlumno() {
		return idAlumno;
	}

	public void setIdAlumno(int idAlumno) {
		this.idAlumno = idAlumno;
	}

	public String getNombreAlumno() {
		return nombreAlumno;
	}

	public void setNombreAlumno(String nombreAlumno) {
		this.nombreAlumno = nombreAlumno;
	}

	public int getIdAsignatura() {
		return idAsignatura;
	}

	public void setIdAsignatura(int idAsignatura) {
		this.idAsignatura = idAsignatura;
	}

	public String getNombreAsignatura() {
		return nombreAsignatura;
	}

	public void setNombreAsignatura(String nombreAsignatura) {
		this.nombreAsignatura = nombreAsignatura;
	}

	public String getFecha() {
		return fecha;
	}

	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

	public Double getTasa() {
		return tasa;
	}

	public void setTasa(Double tasa) {
		this.tasa = tasa;
	}

	public int getActivo() {
		return activo;
	}

	public void setActivo(int activo) {
		this.activo = activo;
	}
}
