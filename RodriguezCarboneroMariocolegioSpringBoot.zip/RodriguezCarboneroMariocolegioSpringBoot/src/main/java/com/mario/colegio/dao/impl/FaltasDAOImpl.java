package com.mario.colegio.dao.impl;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mario.colegio.dao.interfaces.IAlumnosDAO;
import com.mario.colegio.dao.interfaces.IFaltasDAO;
import com.mario.colegio.dtos.FaltasDTO;
import com.mario.colegio.entities.AlumnoEntity;
import com.mario.colegio.entities.AsignaturaEntity;
import com.mario.colegio.entities.FaltasEntity;
import com.mario.colegio.repositories.AlumnoRepository;
import com.mario.colegio.repositories.AsignaturaRepository;
import com.mario.colegio.repositories.FaltasRepository;

import jakarta.transaction.Transactional;

@Repository
public class FaltasDAOImpl implements IFaltasDAO{

	@Autowired
    AsignaturaRepository asignaturaRepository;

    @Autowired
    AlumnoRepository alumnosRepository;

    @Autowired
    FaltasRepository faltasRepository;

    @Override
    @Transactional
    public ArrayList<FaltasDTO> obtenerFaltasPorFiltros(
            String nombreAlumno, String asignatura, String fecha, Integer justificada) {

        return faltasRepository.buscarFaltaporIDyNombre(
                nombreAlumno, asignatura, fecha, justificada);
    }

    @Override
    @Transactional
    public int insertarFalta(Integer idAlumno, Integer idAsignatura, String fecha, Integer justificada) {

        AlumnoEntity alumno = alumnosRepository.findById(idAlumno).orElseThrow();
        AsignaturaEntity asignatura = asignaturaRepository.findById(idAsignatura).orElseThrow();

        FaltasEntity falta = new FaltasEntity();
        falta.setAlumno(alumno);
        falta.setAsignaturas(asignatura);
        falta.setFecha(fecha);
        falta.setJustificada(justificada);

        faltasRepository.save(falta);
        return falta.getIdFalta();
    }

    @Override
    @Transactional
    public int actualizarFalta(Integer idFalta, Integer idAlumno,
            Integer idAsignatura, String fecha, Integer justificada) {

        FaltasEntity falta = faltasRepository.findById(idFalta).orElseThrow();

        falta.setAlumno(alumnosRepository.findById(idAlumno).orElseThrow());
        falta.setAsignaturas(asignaturaRepository.findById(idAsignatura).orElseThrow());
        falta.setFecha(fecha);
        falta.setJustificada(justificada);

        faltasRepository.save(falta);
        return falta.getIdFalta();
    }

    @Override
    @Transactional
    public int borrarFalta(Integer idFalta) {
        FaltasEntity falta = faltasRepository.findById(idFalta).orElseThrow();
        falta.setJustificada(0);
        faltasRepository.save(falta);
        return falta.getIdFalta();
    }

    @Override
    public ArrayList<FaltasDTO> obtenerTodasFaltas() {
        return new ArrayList<>();
    }
	
	
}
