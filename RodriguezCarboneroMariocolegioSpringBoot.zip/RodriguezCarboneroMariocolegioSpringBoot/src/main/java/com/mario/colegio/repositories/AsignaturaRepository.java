package com.mario.colegio.repositories;

import java.util.ArrayList;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.mario.colegio.dtos.AlumnoDTO;
import com.mario.colegio.dtos.AsignaturaDTO;
import com.mario.colegio.entities.AlumnoEntity;
import com.mario.colegio.entities.AsignaturaEntity;

public interface AsignaturaRepository extends CrudRepository<AsignaturaEntity,Integer>{
	
	@Query("SELECT new com.mario.colegio.dtos.AsignaturaDTO(a.id, a.nombre, a.curso, a.tasa, a.activo) " +
	           "FROM AsignaturaEntity a " +
	           "WHERE (:id IS NULL OR CAST(a.id AS string) LIKE CONCAT('%', :id, '%')) " +
	           "AND (:nombre IS NULL OR a.nombre LIKE CONCAT('%', :nombre, '%')) " +
	           "AND (:curso IS NULL OR a.curso LIKE CONCAT('%', :curso, '%')) " +
	           "AND (:tasa IS NULL OR a.tasa >= :tasa) " +
	           "AND a.activo = :activo")
			ArrayList<AsignaturaDTO>buscarAsignaturaporIDyNombre(@Param("id") Integer id,
			@Param("nombre") String nombre,
			@Param("curso") String curso,
			@Param("tasa") Double tasa,
			@Param("activo") Integer activo);
}
