package com.mario.colegio.dao.interfaces;

import java.util.ArrayList;

import com.mario.colegio.dtos.DesplegableDTO;

public interface IDesplegableDAO {

	ArrayList<DesplegableDTO> desplegableMunicipios();
	ArrayList<DesplegableDTO> desplegableAlumnos();
	ArrayList<DesplegableDTO> desplegableAsignaturas();

}
