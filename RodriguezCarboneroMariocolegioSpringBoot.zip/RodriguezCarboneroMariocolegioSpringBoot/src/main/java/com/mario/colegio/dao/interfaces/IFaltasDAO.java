package com.mario.colegio.dao.interfaces;

import java.util.ArrayList;

import com.mario.colegio.dtos.FaltasDTO;

public interface IFaltasDAO {
	ArrayList<FaltasDTO> obtenerTodasFaltas();

    ArrayList<FaltasDTO> obtenerFaltasPorFiltros(String nombreAlumno, String asignatura, String fecha, Integer justificada);

    int insertarFalta(Integer idAlumno, Integer idAsignatura, String fecha, Integer justificada);

    int actualizarFalta(Integer idFalta, Integer idAlumno, Integer idAsignatura, String fecha, Integer justificada);

    int borrarFalta(Integer idFalta);
}
