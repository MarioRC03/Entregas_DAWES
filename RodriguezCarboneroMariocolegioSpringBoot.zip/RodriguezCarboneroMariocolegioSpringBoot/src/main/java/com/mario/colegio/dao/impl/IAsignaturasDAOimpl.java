package com.mario.colegio.dao.impl;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mario.colegio.dao.interfaces.IAsignaturasDAO;
import com.mario.colegio.dtos.AsignaturaDTO;
import com.mario.colegio.entities.AlumnoEntity;
import com.mario.colegio.entities.AsignaturaEntity;
import com.mario.colegio.repositories.AlumnoRepository;
import com.mario.colegio.repositories.AsignaturaRepository;
import com.mario.colegio.repositories.MunicipioRepository;

@Repository
public class IAsignaturasDAOimpl implements IAsignaturasDAO{

	@Autowired
	AsignaturaRepository asignaturaRepository;
	
	@Override
	public ArrayList<AsignaturaDTO> obtenerTodasAsignaturas() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<AsignaturaDTO> obtenerAsignaturasPorFiltros(Integer id, String nombre, String curso, Double tasa,
			int activo) {
		// TODO Auto-generated method stub
		return asignaturaRepository.buscarAsignaturaporIDyNombre(id,nombre,curso,tasa,activo);
	}

	@Override
	public int insertarAsignatura(Integer id, String nombre, String curso, Double tasa, Integer activo) {
		// TODO Auto-generated method stub
		AsignaturaEntity asignatura = new AsignaturaEntity (id,nombre,curso,tasa,activo);
		asignaturaRepository.save(asignatura);
				return asignatura.getId();
	}

	@Override
	public int actualizarAsignatura(Integer id, String nombre, String curso, Double tasa, Integer activo) {
		// TODO Auto-generated method stub
		AsignaturaEntity asignatura = new AsignaturaEntity (id,nombre,curso,tasa,activo);
		asignaturaRepository.save(asignatura);
				return asignatura.getId();
	}

	@Override
	public int borrarAsignatura(Integer id) {
		AsignaturaEntity asignatura = asignaturaRepository.findById(id).get();
		asignatura.setActivo(0);
		asignaturaRepository.save(asignatura);
		return asignatura.getId();
	}
	
	@Override
	public double obtenerTasaAsignatura(String idAsignatura) {
		// TODO Auto-generated method stub
		return 0;
	}

}
