package com.mario.colegio.dao.impl;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mario.colegio.dao.interfaces.IDesplegableDAO;
import com.mario.colegio.dtos.DesplegableDTO;
import com.mario.colegio.entities.AlumnoEntity;
import com.mario.colegio.entities.AsignaturaEntity;
import com.mario.colegio.entities.MunicipioEntity;
import com.mario.colegio.repositories.AlumnoRepository;
import com.mario.colegio.repositories.AsignaturaRepository;
import com.mario.colegio.repositories.MunicipioRepository;

@Repository
public class DesplegablesDAOImpl implements IDesplegableDAO {
	@Autowired // Inyectamos el repository
	private MunicipioRepository municipioRepository;
	@Autowired
	private AlumnoRepository alumnoRepository;

	@Autowired
	private AsignaturaRepository asignaturaRepository;

	@Override
	public ArrayList<DesplegableDTO> desplegableMunicipios() {
		// Utilizamos el método que nos "regala" Spring data JPA
		Iterable<MunicipioEntity> listaEntidadesMunicipios = municipioRepository.findAll();
		ArrayList<DesplegableDTO> listaMunicipios = mapeoEntidadMunicioComboDTO(listaEntidadesMunicipios);
		return listaMunicipios;
	}

	private ArrayList<DesplegableDTO> mapeoEntidadMunicioComboDTO(Iterable<MunicipioEntity> listaEntidadesMunicipios) {
		ArrayList<DesplegableDTO> listaCombos = new ArrayList<>();
		for (MunicipioEntity municipiosEntity : listaEntidadesMunicipios) {
			listaCombos.add(new DesplegableDTO(municipiosEntity.getIdMunicipio(), municipiosEntity.getNombre()));
		}
		return listaCombos;
	}

	@Override
	public ArrayList<DesplegableDTO> desplegableAlumnos() {
		Iterable<AlumnoEntity> listaEntidadesAlumnos = alumnoRepository.findAll();
		ArrayList<DesplegableDTO> listaAlumnos = new ArrayList<>();
		for (AlumnoEntity alumno : listaEntidadesAlumnos) {
			listaAlumnos.add(new DesplegableDTO(alumno.getId(), alumno.getNombre()));
		}
		return listaAlumnos;
	}

	@Override
	public ArrayList<DesplegableDTO> desplegableAsignaturas() {
		Iterable<AsignaturaEntity> listaEntidadesAsignaturas = asignaturaRepository.findAll();
		ArrayList<DesplegableDTO> listaAsignaturas = new ArrayList<>();
		for (AsignaturaEntity asignatura : listaEntidadesAsignaturas) {
			listaAsignaturas.add(new DesplegableDTO(asignatura.getId(), asignatura.getNombre()));
		}
		return listaAsignaturas;
	}

}
