package com.mario.colegio.dao.impl;

import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mario.colegio.dao.interfaces.IMatriculacionesDAO;
import com.mario.colegio.dtos.MatriculacionesDTO;
import com.mario.colegio.entities.AlumnoEntity;
import com.mario.colegio.entities.AsignaturaEntity;
import com.mario.colegio.entities.MatriculacionesEntity;
import com.mario.colegio.repositories.AlumnoRepository;
import com.mario.colegio.repositories.AsignaturaRepository;
import com.mario.colegio.repositories.MatriculacionesRepository;

@Repository
public class MatriculacionesDAOImpl implements IMatriculacionesDAO{

	@Autowired
    private MatriculacionesRepository matriculacionesRepository;

    @Autowired
    private AlumnoRepository alumnosRepository;

    @Autowired
    private AsignaturaRepository asignaturasRepository;

    @Override
    public int insertarMatriculacion(String idAsignatura, String idAlumno, String fecha, Double tasa) {
        AlumnoEntity alumno = alumnosRepository.findById(Integer.parseInt(idAlumno)).orElse(null);
        AsignaturaEntity asignatura = asignaturasRepository.findById(Integer.parseInt(idAsignatura)).orElse(null);

        if (alumno == null || asignatura == null) return -1;

        MatriculacionesEntity matriculacion = new MatriculacionesEntity(alumno, asignatura, fecha, tasa, 1);
        matriculacionesRepository.save(matriculacion);
        return matriculacion.getId();
    }

    @Override
    public int actualizarMatriculacion(Integer id, String idAsignatura, String idAlumno, String fecha, Double tasa) {
        MatriculacionesEntity matriculacion = matriculacionesRepository.findById(id).orElse(null);
        AlumnoEntity alumno = alumnosRepository.findById(Integer.parseInt(idAlumno)).orElse(null);
        AsignaturaEntity asignatura = asignaturasRepository.findById(Integer.parseInt(idAsignatura)).orElse(null);

        if (matriculacion == null || alumno == null || asignatura == null) return -1;

        matriculacion.setAlumno(alumno);
        matriculacion.setAsignatura(asignatura);
        matriculacion.setFecha(fecha);
        matriculacion.setTasa(tasa);

        matriculacionesRepository.save(matriculacion);
        return matriculacion.getId();
    }

    @Override
    public int borrarMatriculacion(Integer id) {
        MatriculacionesEntity matriculacion = matriculacionesRepository.findById(id).orElse(null);
        if (matriculacion == null) return -1;

        matriculacion.setActivo(0);
        matriculacionesRepository.save(matriculacion);
        return matriculacion.getId();
    }

    @Override
    public ArrayList<MatriculacionesDTO> obtenerMatriculacionesPorFiltros(String nombreAsignatura, String nombreAlumno,
    		String fecha, Integer activo) {
        // Llamada al repository usando fecha como Double
        return matriculacionesRepository.buscarMatriculacionporIDyNombre(
            null, null, nombreAsignatura, null, nombreAlumno, fecha, null, activo
        );
    }

    @Override
    public double obtenerTasaAsignatura(String idAsignatura) {
        AsignaturaEntity asignatura = asignaturasRepository.findById(Integer.parseInt(idAsignatura)).orElse(null);
        if (asignatura == null) return 0;
        return asignatura.getTasa();
    }

}
