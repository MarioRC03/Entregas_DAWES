package com.mario.colegio.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "faltas")

public class FaltasEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "idfaltas")
	private int idFalta;
	@Column(name = "fecha")
	private String fecha;
	@Column(name = "justificada")
	private int justificada;
	@ManyToOne
	@JoinColumn(name = "alumno")
	private AlumnoEntity alumno;
	@ManyToOne
	@JoinColumn(name = "asignatura")
	private AsignaturaEntity asignaturas;

	public FaltasEntity(int idFalta, String fecha, int justificada, AlumnoEntity alumno,
			AsignaturaEntity asignaturas) {
		super();
		this.idFalta = idFalta;
		this.fecha = fecha;
		this.justificada = justificada;
		this.alumno = alumno;
		this.asignaturas = asignaturas;
	}
	

	public FaltasEntity(int idAlumno, int asignatura, String fecha, int justificada, AlumnoEntity alumno,
			AsignaturaEntity asignaturas) {
		super();
		this.fecha = fecha;
		this.justificada = justificada;
		this.alumno = alumno;
		this.asignaturas = asignaturas;
	}


	public FaltasEntity() {
		super();
	}


	public FaltasEntity(Integer idAlumno, Integer idAsignatura, String fecha, Integer justificada) {
		this.fecha = fecha;
		this.justificada = justificada;
	}


	public int getIdFalta() {
		return idFalta;
	}

	public void setIdFalta(int idFalta) {
		this.idFalta = idFalta;
	}

	public String getFecha() {
		return fecha;
	}

	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

	public int getJustificada() {
		return justificada;
	}

	public void setJustificada(int justificada) {
		this.justificada = justificada;
	}

	public AlumnoEntity getAlumno() {
		return alumno;
	}

	public void setAlumno(AlumnoEntity alumno) {
		this.alumno = alumno;
	}

	public AsignaturaEntity getAsignaturas() {
		return asignaturas;
	}

	public void setAsignaturas(AsignaturaEntity asignaturas) {
		this.asignaturas = asignaturas;
	}

}
