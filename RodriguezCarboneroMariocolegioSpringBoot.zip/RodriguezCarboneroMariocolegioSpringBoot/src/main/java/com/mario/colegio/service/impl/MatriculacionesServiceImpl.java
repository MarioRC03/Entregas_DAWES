package com.mario.colegio.service.impl;

import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mario.colegio.dao.interfaces.IAsignaturasDAO;
import com.mario.colegio.dao.interfaces.IMatriculacionesDAO;
import com.mario.colegio.dtos.MatriculacionesDTO;
import com.mario.colegio.service.interfaces.IMatriculacionesService;

@Service
public class MatriculacionesServiceImpl implements IMatriculacionesService {

	@Autowired
	IMatriculacionesDAO matriculacionesDAO;
	
	@Override
	public double calcularTasa(String idAlumno, String idAsignatura) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insertarMatriculacion(String idAsignatura, String idAlumno, String fecha, Double tasa) {
		// TODO Auto-generated method stub
			return matriculacionesDAO.insertarMatriculacion(idAsignatura, idAlumno, fecha, tasa);

	}

	@Override
	public ArrayList<MatriculacionesDTO> obtenerMatriculacionesPorFiltros(String nombreAsignatura, String nombreAlumno,
			String fecha, Integer activo) {
		// TODO Auto-generated method stub
		return matriculacionesDAO.obtenerMatriculacionesPorFiltros(nombreAsignatura, nombreAlumno, fecha, activo);
	}


	@Override
	public int actualizarMatriculacion(Integer id, String idAsignatura, String idAlumno, String fecha, Double tasa) {
		// TODO Auto-generated method stub
		return matriculacionesDAO.actualizarMatriculacion(id, idAsignatura, idAlumno, fecha, tasa);
	}

	@Override
	public int borrarMatriculacion(Integer id) {
		// TODO Auto-generated method stub
		return matriculacionesDAO.borrarMatriculacion(id);
	}

}
