package com.mario.colegio.dao.interfaces;

import java.util.ArrayList;

import com.mario.colegio.dtos.AsignaturaDTO;

public interface IAsignaturasDAO {
    ArrayList<AsignaturaDTO> obtenerTodasAsignaturas();

    ArrayList<AsignaturaDTO> obtenerAsignaturasPorFiltros(Integer id, String nombre, String curso, Double tasa,
            int activo);

    int insertarAsignatura(Integer id, String nombre, String curso, Double tasa, Integer activo);

    int actualizarAsignatura(Integer id, String nombre, String curso, Double tasa, Integer activo);

    int borrarAsignatura(Integer id);
    
    double obtenerTasaAsignatura(String idAsignatura);
}
