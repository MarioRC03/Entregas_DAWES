package com.mario.colegio.service.interfaces;

import java.sql.SQLException;
import java.util.ArrayList;

import com.mario.colegio.dtos.AsignaturaDTO;

public interface IAsignaturasService {
	 public ArrayList<AsignaturaDTO> obtenerAsignaturas() throws SQLException;

	    public ArrayList<AsignaturaDTO> obtenerAsignaturasPorFiltros(Integer id, String nombre, String curso, Double tasa,
	    		Integer activo);

	    public int insertarAsignatura(Integer id, String nombre, String curso, Double tasa, Integer activo);

	    public int actualizarAsignatura(Integer id, String nombre, String curso, Double tasa, Integer activo);

	    public int borrarAsignatura(Integer id);
}
