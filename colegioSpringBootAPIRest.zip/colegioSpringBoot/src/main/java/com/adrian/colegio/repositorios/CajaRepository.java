package com.adrian.colegio.repositorios;

import org.springframework.data.repository.CrudRepository;

import com.adrian.colegio.entities.CajaEntity;

public interface CajaRepository extends CrudRepository<CajaEntity, Integer> {

}
