package com.adrian.colegio.controladores.rest;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.adrian.colegio.dtos.AsignaturaDTO;
import com.adrian.colegio.servicio.interfaces.IAsignaturasService;

@RestController
@RequestMapping("/colegio/v1")
public class AsignaturasRestController {

    @Autowired
    private IAsignaturasService asignaturasService;

    @PostMapping("/insertarasignaturas")
    public ResponseEntity<String> insertarAsignatura(@RequestBody AsignaturaDTO dto) {
        int resultado = asignaturasService.insertarAsignatura(
                dto.getId(),
                dto.getNombre(),
                dto.getCurso(),
                dto.getTasa(),
                dto.getActivo()
        );
        if (resultado > 0) {
            return new ResponseEntity<>("Asignatura creada correctamente", HttpStatus.CREATED);
        }
        return new ResponseEntity<>("Error al crear la asignatura", HttpStatus.BAD_REQUEST);
    }

    // No existe método obtener todas → puedes implementarlo en el service si lo necesitas
    // @GetMapping("/asignaturas")
    // public ResponseEntity<List<AsignaturaDTO>> listarTodas() {
    //     return ResponseEntity.ok(asignaturasService.obtenerTodasAsignaturas());
    // }

    @GetMapping("/asignaturastodas")
    public ResponseEntity<AsignaturaDTO> obtenertodos() {
        // Como no hay método obtenerPorId, usamos el filtro con id exacto
        ArrayList<AsignaturaDTO> resultado = asignaturasService.obtenerAsignaturasPorFiltros(null, null, null, null, null);
        if (resultado == null || resultado.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(resultado.get(0));
    }
    
    @GetMapping("/asignaturas/{id}")
    public ResponseEntity<AsignaturaDTO> obtenerPorId(@PathVariable Integer id) {
        // Como no hay método obtenerPorId, usamos el filtro con id exacto
        ArrayList<AsignaturaDTO> resultado = asignaturasService.obtenerAsignaturasPorFiltros(id, null, null, null, null);
        if (resultado == null || resultado.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(resultado.get(0));
    }

    @GetMapping(value = "/asignaturas")
    public ResponseEntity<List<AsignaturaDTO>> buscarConFiltros(
            @RequestParam(value = "id", required = false) Integer id,
            @RequestParam(value = "nombre", required = false) String nombre,
            @RequestParam(value = "curso", required = false) Integer curso,
            @RequestParam(value = "tasa", required = false) Double tasa,
            @RequestParam(value = "activo", required = false) Integer activo) {

        ArrayList<AsignaturaDTO> lista = asignaturasService.obtenerAsignaturasPorFiltros(id, nombre, curso, tasa, activo);
        return ResponseEntity.ok(lista);
    }

    @PutMapping("/asignaturas/{id}")
    public ResponseEntity<?> actualizarAsignatura(
            @PathVariable Integer id,
            @RequestBody AsignaturaDTO dto) {

        if (!id.equals(dto.getId())) {
            return ResponseEntity.badRequest().body("ID en URL y cuerpo no coinciden");
        }

        ArrayList<AsignaturaDTO> existe = asignaturasService.obtenerAsignaturasPorFiltros(id, null, null, null, null);
        if (existe.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        int resultado = asignaturasService.actualizarAsignatura(
                dto.getId(),
                dto.getNombre(),
                dto.getCurso(),
                dto.getTasa(),
                dto.getActivo()
        );

        if (resultado > 0) {
            return ResponseEntity.ok("Asignatura actualizada correctamente");
        }
        return ResponseEntity.badRequest().body("Error al actualizar");
    }

    @DeleteMapping("/borrarasignaturas/{id}")
    public ResponseEntity<?> borrarAsignatura(@PathVariable Integer id) {
        ArrayList<AsignaturaDTO> existe = asignaturasService.obtenerAsignaturasPorFiltros(id, null, null, null, null);
        if (existe.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        int resultado = asignaturasService.borrarAsignatura(id);
        if (resultado > 0) {
            return new ResponseEntity<>("Asignatura eliminada (lógico)", HttpStatus.OK);
        }
        return new ResponseEntity<>("Error al eliminar", HttpStatus.BAD_REQUEST);
    }
}