package com.adrian.colegio.controladores.rest;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.adrian.colegio.dtos.MatriculacionDTO;
import com.adrian.colegio.servicio.interfaces.IMatriculacionesService;

@RestController
@RequestMapping("/colegio/v1")
public class MatriculacionesRestController {

    @Autowired
    private IMatriculacionesService matriculacionesService;

    // 1. Listar todas las matriculaciones o buscar con filtros
    // GET /colegio/v1/matriculaciones
    // GET /colegio/v1/matriculaciones?asignatura=Matemáticas&nombreAlumno=Juan&fecha=2026-02-01&activo=1
    @GetMapping("/matriculaciones")
    public ResponseEntity<List<MatriculacionDTO>> buscarMatriculaciones(
            @RequestParam(value = "asignatura", required = false) String asignatura,
            @RequestParam(value = "nombreAlumno", required = false) String nombreAlumno,
            @RequestParam(value = "fecha", required = false) String fechaStr,
            @RequestParam(value = "activo", required = false) Integer activo) {

        // Si no se pasa fecha → usamos la fecha actual (como pide la especificación)
        String fechaFiltro = (fechaStr != null && !fechaStr.trim().isEmpty())
                ? fechaStr
                : LocalDate.now().toString();

        List<MatriculacionDTO> matriculaciones = matriculacionesService.obtenerMatriculacionesPorFiltros(
                null,
                null,
                null,
                null
        );

        return ResponseEntity.ok(matriculaciones);
    }

    // 2. Obtener una matriculación específica por ID
    // GET /colegio/v1/matriculaciones/123
    @GetMapping("/matriculaciones/{id}")
    public ResponseEntity<MatriculacionDTO> obtenerPorId(@PathVariable Integer id) {

        // Opción A: si tu servicio ya tiene un método findById → úsalo (recomendado)
        // Opción B: si no lo tienes, puedes usar el filtro y buscar (menos eficiente)

        // Versión recomendada (si agregas este método al service en el futuro):
        // Optional<MatriculacionDTO> matriculaOpt = matriculacionesService.findById(id);

        // Versión actual compatible con tu interfaz existente:
        List<MatriculacionDTO> todas = matriculacionesService.obtenerMatriculacionesPorFiltros(null, null, null, null);
        
        Optional<MatriculacionDTO> matriculaOpt = todas.stream()
                .filter(m -> m.getId() != null && m.getId().equals(id))
                .findFirst();

        return matriculaOpt
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // 3. Crear nueva matriculación
    @PostMapping("/matriculaciones")
    public ResponseEntity<MatriculacionDTO> insertarMatriculacion(@RequestBody MatriculacionDTO dto) {

        // Usamos fecha actual si no viene en el DTO
        String fechaStr = (dto.getFecha() != null)
                ? dto.getFecha().toString()
                : LocalDate.now().toString();

        int idGenerado = matriculacionesService.insertarMatriculacion(
                dto.getIdAlumno(),
                dto.getIdAsignatura(),
                fechaStr,
                dto.getTasa()
        );

        if (idGenerado <= 0) {
            return ResponseEntity.badRequest().build();
        }

        // Opción ideal: volver a consultar el DTO recién creado
        // Por ahora simulamos retornando el DTO con ID asignado
        dto.setId(idGenerado);
        // dto.setActivo(1);  // si el servicio lo establece por defecto

        return new ResponseEntity<>(dto, HttpStatus.CREATED);
    }

    // 4. Actualizar matriculación
    @PutMapping("/matriculaciones/{id}")
    public ResponseEntity<MatriculacionDTO> actualizarMatriculacion(
            @PathVariable Integer id,
            @RequestBody MatriculacionDTO dto) {

        // Verificamos existencia (puedes optimizar esto cuando tengas findById)
        List<MatriculacionDTO> todas = matriculacionesService.obtenerMatriculacionesPorFiltros(null, null, null, null);
        boolean existe = todas.stream().anyMatch(m -> m.getId() != null && m.getId().equals(id));

        if (!existe) {
            return ResponseEntity.notFound().build();
        }

        String fechaStr = (dto.getFecha() != null) ? dto.getFecha().toString() : null;

        int filasAfectadas = matriculacionesService.actualizarMatriculacion(
                id,
                dto.getIdAlumno(),
                dto.getIdAsignatura(),
                fechaStr,
                dto.getTasa()
        );

        if (filasAfectadas <= 0) {
            return ResponseEntity.badRequest().build();
        }

        // Ideal: retornar el DTO actualizado
        // Por ahora devolvemos el DTO recibido + id
        dto.setId(id);
        return ResponseEntity.ok(dto);
    }

    // 5. Eliminar / desactivar matriculación
    @DeleteMapping("/matriculaciones/{id}")
    public ResponseEntity<String> borrarMatriculacion(@PathVariable Integer id) {

        // Verificar existencia
        List<MatriculacionDTO> todas = matriculacionesService.obtenerMatriculacionesPorFiltros(null, null, null, null);
        boolean existe = todas.stream().anyMatch(m -> m.getId() != null && m.getId().equals(id));

        if (!existe) {
            return ResponseEntity.notFound().build();
        }

        int resultado = matriculacionesService.borrarMatriculacion(id);

        if (resultado > 0) {
            return ResponseEntity.ok("Matriculación eliminada correctamente");
        }

        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body("Error al eliminar la matriculación");
    }
}