package com.adrian.colegio.controladores.rest;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.adrian.colegio.dtos.FaltaDTO;
import com.adrian.colegio.servicio.interfaces.IFaltasService;

@RestController
@RequestMapping("/colegio/v1")
public class FaltasRestController {

    @Autowired
    private IFaltasService faltasService;

    @PostMapping("/faltas")
    public ResponseEntity<String> insertarFalta(@RequestBody FaltaDTO dto) {
        int resultado = faltasService.insertarFalta(
                dto.getIdAlumno(),
                dto.getIdAsignatura(),
                dto.getFecha() != null ? dto.getFecha().toString() : LocalDate.now().toString(),
                dto.getJustificada()
        );
        if (resultado > 0) {
            return new ResponseEntity<>("Falta registrada", HttpStatus.CREATED);
        }
        return new ResponseEntity<>("Error al registrar falta", HttpStatus.BAD_REQUEST);
    }

    // No existe método obtenerTodas → opcional implementarlo
    // @GetMapping("/faltas")
    // public ResponseEntity<List<FaltaDTO>> listarTodas() { ... }

    @GetMapping("/faltas/{id}")
    public ResponseEntity<FaltaDTO> obtenerFaltaPorId(@PathVariable Integer id) {
        // Usamos filtro por id (asumiendo que el DAO lo soporta)
        // Nota: probablemente tengas que añadir un método obtenerPorId en el service/DAO
        ArrayList<FaltaDTO> resultado = faltasService.obtenerFaltasPorFiltros(null, null, null, null, null, null);
        // Filtrar manualmente por ahora (mejorar con método específico)
        for (FaltaDTO f : resultado) {
            if (f.getIdFalta().equals(id)) {
                return ResponseEntity.ok(f);
            }
        }
        return ResponseEntity.notFound().build();
    }

    @GetMapping(value = "/todasfaltas")
    public ResponseEntity<List<FaltaDTO>> buscarFaltas(
            @RequestParam(value = "idAlumno", required = false) Integer idAlumno,
            @RequestParam(value = "nombreAlumno", required = false) String nombreAlumno,
            @RequestParam(value = "asignatura", required = false) String asignatura,
            @RequestParam(value = "fecha", required = false) String fecha,
            @RequestParam(value = "justificada", required = false) Integer justificada,
            @RequestParam(value = "activo", required = false) Integer activo) {

        if (fecha == null || fecha.trim().isEmpty()) {
            fecha = LocalDate.now().toString();
        }

        ArrayList<FaltaDTO> resultado = faltasService.obtenerFaltasPorFiltros(null, null, null, null, null, null);
        return ResponseEntity.ok(resultado);
    }

    @PutMapping("/faltas/{id}")
    public ResponseEntity<?> actualizarFalta(
            @PathVariable Integer id,
            @RequestBody FaltaDTO dto) {

        // Comprobar existencia (usando filtro o añadiendo método obtenerPorId)
        ArrayList<FaltaDTO> existe = faltasService.obtenerFaltasPorFiltros(null, null, null, null, null, null);
        boolean found = existe.stream().anyMatch(f -> f.getIdFalta().equals(id));
        if (!found) {
            return ResponseEntity.notFound().build();
        }

        int resultado = faltasService.actualizarFalta(
                id,
                dto.getIdAlumno(),
                dto.getIdAsignatura(),
                dto.getFecha() != null ? dto.getFecha().toString() : null,
                dto.getJustificada()
        );

        if (resultado > 0) {
            return ResponseEntity.ok("Falta actualizada");
        }
        return ResponseEntity.badRequest().body("Error al actualizar falta");
    }

    @DeleteMapping("/faltas/{id}")
    public ResponseEntity<?> borrarFalta(@PathVariable Integer id) {
        // Comprobar existencia
        ArrayList<FaltaDTO> existe = faltasService.obtenerFaltasPorFiltros(null, null, null, null, null, null);
        boolean found = existe.stream().anyMatch(f -> f.getIdFalta().equals(id));
        if (!found) {
            return ResponseEntity.notFound().build();
        }

        int resultado = faltasService.borrarFalta(id);
        if (resultado > 0) {
            return new ResponseEntity<>("Falta eliminada", HttpStatus.OK);
        }
        return new ResponseEntity<>("Error al eliminar", HttpStatus.BAD_REQUEST);
    }
}